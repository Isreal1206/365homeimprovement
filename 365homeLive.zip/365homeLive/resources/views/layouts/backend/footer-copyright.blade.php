<footer class="site-footer">
  <div class="text-center">
    <p>
      &copy; 2019 <strong>Hausworth Nigeria Limited.</strong>
    </p>
    <a href="{{url('#')}}" class="go-top">
      <i class="fa fa-angle-up"></i>
    </a>
  </div>
</footer>