<!DOCTYPE html>
<html lang="en">
<head>
  @yield('heading')
</head>

<body>
	<main>
        @yield('content')
    </main>
</body>

@yield('footer')
</html>
