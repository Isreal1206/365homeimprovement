<!--this is the body of the mail that will be sent-->
<h3>You have a New CV for the Accountant job position</h3>

<p>You have received a new job application from {{$name}} with email {{$email}}. Please download to view the CV</p>
