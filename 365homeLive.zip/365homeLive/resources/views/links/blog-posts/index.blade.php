<!DOCTYPE html>
<html lang="en">
<head>
  @include('layouts.header')
  @include('layouts.navbar')
  {{--<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/sweetalert2@8.11.7/dist/sweetalert2.min.css">--}}
  {!! Html::style('css/select2.min.css') !!}
  <link href="{{ asset('css/sidebar.css') }}" rel="stylesheet">
  <link href="{{ asset('css/sweetalert2.min.css') }}" rel="stylesheet">
</head>

<body class="bg-links"> 
  <section class="roboto intro-banner">
    <div class="container-fluid p-0">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3">
          <div class="border-right sidenav">
            @include('layouts.sidebar')
          </div>
        </div>
        <div class="col-12 col-sm-12 col-md-12 col-lg-9 col-xl-9">
          <div class="container mb-5">
            <div class="row">
              <div class="col-12 my-4">
                <div class="py-1 px-3 bg-light">
                  <h5 class="text-bold pt-2"> ALL POSTS </h5>
                </div>
                <div class="border-warning" style="border-top: 5px solid"></div>
              </div>
            </div>

            @include('inc.messages')
            @if(count($posts)<=0)
              <p>No posts found.</p>
            @else
              <div class="row">
                <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                  <div class="table-responsive">
                    <table class="table table-striped">
                      @foreach($posts as $post)
                      <tr>
                        <td><img src="{{ asset('img/img_blog/' . $post->image_file) }}" class="img-responsive mx-auto" style="width: 100px; height: 100px" alt="IMAGE"/></td>

                        <td><span class="text-uppercase text-bold" style="font-size: .9rem;">{{$post->title}}</span><br>
                        <small>Posted by <strong>{{$post->user->firstname}}<i class="mr-1"></i>{{$post->user->lastname}}</strong> on {{ date('j M Y, h:iA', strtotime($post->created_at)) }}</small></td>

                        <td><a href="/blog-posts/{{$post->id}}"><i class="fa fa-eye text-primary"></i></a></td>

                        <td>@if(Auth::user()->id == $post->user_id)
                          <a href="/blog-posts/{{$post->id}}/edit"><i class="fa fa-edit text-success"></i></a>@endif</td>

                        <td>@if(Auth::user()->id == $post->user_id)
                          <form action="{!! action('PostsController@destroy', $post->id) !!}" method="POST" name="deletePost">
                        <input type="hidden" name="_method" value="DELETE">
                        {{csrf_field()}}
                        <a onclick="delPost()"><i class="fa fa-trash text-danger"></i></a>
                        </form>@endif</td>
                        {{--@endif--}}
                      </tr>
                      @endforeach
                    </table>
                  </div>
                </div>
              </div>
              {{$posts->links()}}
            @endif
          </div>
        </div>
      </div>
    </div>
  </section>
<!--/ footer Star /-->
  @include('layouts.footer')
<!--/ Footer End /-->

{!! Html::script('js/sweetalert2.min.js') !!}
<script>
  function delPost() {
    event.preventDefault();
    var form = document.forms["deletePost"];
      Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'Cancel'
      }).then((result) => {
      if (result.value) {
        form.submit();
        Swal.fire('Deleted!', 'Your post has been deleted.', 'success')
      } else { 
        Swal.fire('Cancelled', 'Your post is safe.', 'error')
      }
    })
  }
</script>
{{--<script type="text/javascript">
  $(".delete-post").on("submit", function(){
    return confirm("Are you sure you want to delete?");
  });
</script>--}}

</body>
</html>
  