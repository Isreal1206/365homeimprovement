<!DOCTYPE html>
<html lang="en">
<head>
  @include('layouts.header')
  @include('layouts.navbar')
  {{--<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />--}}
  {!! Html::style('css/select2.min.css') !!}
  <link href="{{ asset('css/sidebar.css') }}" rel="stylesheet">
</head>

<body class="bg-links"> 
  <section class="roboto intro-banner">
    <div class="container-fluid p-0">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
          <div class="border-right sidenav">
            @include('layouts.sidebar')
          </div>
        </div>
        <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
          <div class="container mb-5">
            <div class="row">
              <div class="col-12 my-4">
                <div class="py-1 px-3 bg-light">
                  <h5 class="text-bold pt-2"> EDIT POST </h5>
                </div>
                <div class="border-warning" style="border-top: 5px solid"></div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-9">
                @include('inc.messages')
                {!! Form::model($post, ['route' => ['blog-posts.update', $post->id], 'method' => 'PUT', 'files' => true]) !!}

                <div class="form-group">
                  {{ Form::label('title', 'Title:')}}
                  {{ Form::text('title', null, ["class" => 'form-control input-lg']) }}
                </div>

                {{--<div class="form-group">
                  {{ Form::label('slug', 'Slug:', ['class' => 'form-spacing-top']) }}
                  {{ Form::text('slug', null, ['class' => 'form-control']) }}
                </div>

                <div class="form-group">
                  {{ Form::label('category_id', "Category:", ['class' => 'form-spacing-top']) }}
                  {{ Form::select('category_id', $categories, null, ['class' => 'form-control']) }}
                </div> --}}

                <div class="form-group">
                  {{ Form::label('tags', "Tags:", ['class' => 'form-spacing-top']) }}
                  {{ Form::select('tags[]',  $tags, null, ['id' => 'multiple-select', 'class' => 'form-control', 'multiple' => 'multiple']) }}
                  
                </div>

                <div class="form-group">
                  {{ Form::label('body', "Body:", ['class' => 'form-spacing-top']) }}
                  {{ Form::textarea('body', null, ['id' => 'article-ckeditor', 'class' => 'form-control']) }}
                </div>

                <small class="text-secondary">Attachment: (Maximum size: 2MB) </small>
                <div class="input-group">
                  <input type="file" accept="image/png, image/jpeg, image/gif" name="image_file"/> <!-- rename it -->
                </div>

                <div class="form-group">
                  {{ Form::submit('Save Post', ['class' => 'btn btn-success my-2']) }}
                </div>
                {!! Form::close() !!}
              </div>
            </div>
          </div>
        </div>
      </div>  
    </div>
  </section>
<!--/ footer Star /-->
  @include('layouts.footer-copyright')
<!--/ Footer End /-->

{{--<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>--}}
{!! Html::script('js/select2.min.js') !!}

<script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
<script>
  CKEDITOR.replace( 'article-ckeditor' );
</script>

<script type="text/javascript">
    $('#multiple-select').select2();
    {{--$('#multiple-select').select2().val({!! json_encode($post->tags()->getRelatedIds()) !!}).trigger('change');--}}
</script>

</body>
</html>
