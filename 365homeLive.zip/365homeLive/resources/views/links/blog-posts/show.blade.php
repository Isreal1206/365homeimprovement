<!DOCTYPE html>
<html lang="en">
<head>
  @include('layouts.header')
  @include('layouts.navbar')
  <link href="{{ asset('css/sidebar.css') }}" rel="stylesheet">
</head>

<body class="bg-links">
  {{--@guest--}}
  <section class="roboto">
    <div class="container-fluid p-0">
        <div class="row">
          <div class="col-12 col-sm-12 col-md-12 col-lg-12">
            <div class="banner-head mb-0">
              <img class="img-responsive img-fluid banner-bg" src="{{URL::to('/')}}/img/page-banner.jpg" alt="Page Banner"/>
              <div class="banner-overlay2">
                <h1 class="text-orange text-center" style="font-size: 1.2rem; font-weight: 900; margin-top: 7rem">HAUSWORTH NIGERIA LIMITED</span></h1>
                <p style="color: white; font-size: 1.2rem" class="position-relative text-center mt-2 mb-0">
                <img src="{{('/img/365Logo.png')}}" class="img-responsive thumbnail30"/>
                <span class="text-absolute">365HomeImprovement</span></p>
                <p class="text-center text-primary ml-3"><small>Nigeria’s One Stop Home Improvement Portal...</small></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="container-fluid bg-black roboto">
        <div class="row ml-5">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 text-footer py-2">
          <span class="mr-2"><a href="{{route('index')}}" class="text-footer"><i class="fa fa-home"></i> Home</a></span>
          <i class="fa fa-angle-double-right"></i>
              <span class="mx-2 text-bold"><a href="{{url('blog')}}" class="text-footer">Blog</a></span>
              <i class="fa fa-angle-double-right"></i>
          <span class="mx-2 text-bold"><a href="{{url('#')}}" class="text-footer">Blog Post</a></span>
          </div>
        </div>
    </div>

    <div class="container my-5">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-10 col-lg-10 mx-auto">
          <div class="bg-light border-light p-4">        
            <div class="post-content">
              <span class="post-date pull-right mb-2"><i class="fa fa-calendar"></i> {{$post->created_at->format ('D, d M Y')}}</span>
              <div class="post-img my-1">
                <img src="{{ asset('img/img_blog/' . $post->image_file) }}" class="img-responsive img-size d-block mx-auto" alt="IMAGE" />
              </div>
              <div class="text-center text-uppercase my-3 P-5">
                <h5 class="text-bold">{{$post->title}}</h5>
              </div>
              <div class="post-content mt-3 text-justify P-5">
                {!! $post->body !!}
              </div>
            </div>
          
            <div class="post-footer row mt-5">
              <div class="col-12 mb-2">
                <span class="text-capitalize"><i class="fa fa-user"><strong> Posted by:</strong> {{$post->user->firstname}} {{$post->user->lastname}}</i></span>
              </div>
              <div class="col-12"> <i class="fa fa-tags mr-1"></i><strong>Tag(s):</strong>
                @foreach($post->tags as $tag)
                <span class="badge badge-warning py-1 px-2 text-capitalize"> {{$tag->name}} </span>
                @endforeach
              </div>
            </div>
          </div>
        </div>

        <div class="col-12 col-sm-12 col-md-10 col-lg-10 mx-auto">
          <h5 class="mt-5">Related Posts</h5>
          <div class="table table-striped box-shadow">
          <table class="w-100">
            @foreach($tag->posts as $post)
            <tr> <td class="w-75" style="font-size: .9rem">{{$post->title}}</td>
            <td class="w-25"><small><a href="/blog-posts/{{$post->id}}" class="text-primary pull-right">Read More<i class="fa fa-angle-double-right ml-1"></i></a></small>
            </td> </tr>
            @endforeach
          </table>
          </div>
        </div>
        </div>
      </div>      
    </div>
  </section>

  {{--@else--}}         
  
  {{--<section class="roboto">
    <div class="container-fluid p-0">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
          <div class="border-right sidenav">
            @include('layouts.sidebar')
          </div>
        </div>
        <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
          <div class="container">
            <div class="row">
              <div class="col-12 my-4">
                <div class="py-1 px-3 bg-light">
                  <h5 class="text-bold pt-2"> BLOG POST </h5>
                </div>
                <div class="border-warning" style="border-top: 5px solid"></div>
              </div>
            </div>

            <div class="row">
              <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                <div class="bg-light border-light p-4">        
                  <div class="post-content">
                    <span class="post-date pull-right mb-2"><i class="fa fa-calendar"></i> {{$post->created_at->format ('D, d M Y')}}</span>
                    <div class="post-img my-1">
                      <img src="{{ asset('img/img_blog/' . $post->image_file) }}" class="img-responsive img-size d-block mx-auto" alt="IMAGE" />
                    </div>
                    <div class="text-center text-uppercase my-3 P-5">
                      <h5 class="text-bold">{{$post->title}}</h5>
                    </div>
                    <div class="post-content mt-3 text-justify P-5">
                      {!! $post->body !!}
                    </div>
                  </div>
                
                  <div class="post-footer row mt-5">
                    <div class="col-12 mb-2">
                      <span class="text-capitalize"><i class="fa fa-user"><strong> Posted by:</strong> {{$post->user->firstname}} {{$post->user->lastname}}</i></span>
                    </div>
                    <div class="col-12"> <i class="fa fa-tags mr-1"></i><strong>Tag(s):</strong>
                      @foreach($post->tags as $tag)
                      <span class="badge badge-warning py-1 px-2 text-capitalize"> {{$tag->name}} </span>
                      @endforeach
                    </div>
                  </div> 
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                <h5 class="mt-5">Related Posts</h5>
                <div class="table table-striped box-shadow">
                <table class="w-100">
                  @foreach($tag->posts as $post)
                  <tr> <td class="w-75" style="font-size: .9rem">{{$post->title}}</td>
                  <td class="w-25"><small><a href="/blog-posts/{{$post->id}}" class="text-primary pull-right">Read More<i class="fa fa-angle-double-right ml-1"></i></a></small>
                  </td> </tr>
                  @endforeach
                </table>
                </div>
              </div>
            </div>
          </div>      
        </div>
      </div>
    </div>
  </section>--}}
  {{--@endguest--}}
<!--/ footer Star /-->
  @include('layouts.footer-copyright')
<!--/ Footer End /-->

</body>
</html>
