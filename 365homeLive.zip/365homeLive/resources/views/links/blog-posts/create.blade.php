<!DOCTYPE html>
<html lang="en">
<head>
  @include('layouts.header')
  @include('layouts.navbar')
  {{--<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />--}}
  {!! Html::style('css/select2.min.css') !!}
  <link href="{{ asset('css/sidebar.css') }}" rel="stylesheet">
</head>

<body class="bg-links"> 
  <section class="roboto intro-banner">
    <div class="container-fluid p-0">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
          <div class="border-right sidenav">
            @include('layouts.sidebar')
          </div>
        </div>
        <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
          <div class="container mb-5">
            <div class="row">
              <div class="col-12 my-4">
                <div class="py-1 px-3 bg-light">
                  <h5 class="text-bold pt-2"> CREATE POST </h5>
                </div>
                <div class="border-warning" style="border-top: 5px solid"></div>
              </div>
            </div>
            <div class="col-md-9">
            @include('inc.messages')
            <form action="{{ route('blog-posts.store') }}" method="POST" enctype="multipart/form-data">
              {{csrf_field()}}
              <div class="form-group">
                <label for="title">Title</label>
                <input type="text" class="form-control" name="title">
              </div>
              <div class="form-group">
                <label for="tags">Tags:</label>
                <select id="multiple-select" class="form-control js-example-basic-multiple" name="tags[]" multiple="multiple">
                  {{--<option value="News">News</option>
                  <option value="Sport">Sport</option>
                  <option value="Entertainment">Entertainment</option>--}}
                  @foreach($tags as $tag)
                  <option value="{{$tag->id}}">{{$tag->name}}</option>
                  @endforeach
                </select>
              </div>
              <div class="form-group">
                <label for="">Body</label>
                <textarea name='body' id="article-ckeditor" class="form-control" rows= "7"></textarea>
              </div>
              <p> <small>Attachment: (Maximum Upload Size: 2MB)</small> </p>
              <div class="input-group">
                <input type="file" accept="image/png, image/jpeg, image/gif" name="image_file"/> <!-- rename it -->
              </div>
              <button type="submit" class="btn btn-orange mt-3">Submit</button>
            </form>
          </div>
          <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
          <script>
            CKEDITOR.replace( 'article-ckeditor' );
          </script>
          </div>
        </div>
      </div>
    </div>    
  </section>
<!--/ footer Star /-->
  @include('layouts.footer-copyright')
<!--/ Footer End /-->

{{--<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>--}}
{!! Html::script('js/select2.min.js') !!}
<script type="text/javascript">
    $('#multiple-select').select2();
</script>

</body>
</html>


<!-- <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
<script> CKEDITOR.replace( 'article-ckeditor' ); </script> -->
