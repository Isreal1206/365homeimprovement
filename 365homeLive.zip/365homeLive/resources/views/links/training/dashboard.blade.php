<!DOCTYPE html>
<html lang="en">
<head>
  @include('layouts.header')
  @include('layouts.navbar')
  <link href="{{ asset('css/sidebar.css') }}" rel="stylesheet">
</head>

<body class="bg-links">
  <section class="roboto intro-banner">
    <div class="container-fluid">
      <div class="row py-4">
        <div class="col-12">
          <span class="offset-md-1 text-bold">EDIT PROFILE</span>
          <span class="pull-right mr-5"><a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
          <i class="fa fa-sign-out mr-1"></i>Logout</a>
          <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display:none;"> @csrf</form>
        </span>
        </div>
        <div class="col-9 col-sm-9 col-md-9 col-lg-9 col-xl-9 offset-md-1">
          <div class="py-2 px-4">
  	      <form action="" method="POST">
  	      	<div class="row border border-links py-3">
              <div class="col-12">
                <h5 class="text-center text-bold">COMPANY DETAILS</h5>
              </div>
              <div class="form-group row px-3">
                <label for="company_name" class="col-5 col-form-label text-md-right">Company Name:</label>
                <div class="col-7">
                <input type="text" name="company_name" class="form-control">
                </div>
                
                <label for="profile" class="col-5 col-form-label text-md-right">Company Profile:</label>
                <div class="col-7">
                <input type="text" name="profile" class="form-control">
                </div>

                <label for="logo" class="col-5 col-form-label text-md-right">Company Logo:</label>

                <div class="col-7">
                  <input id="logo" type="file" accept="image/png, image/jpeg, image/gif" name="logo" value="{{ old('logo') }}" required>

                  @if ($errors->has('logo'))
                    <span class="invalid-feedback" role="alert">
                      <strong>{{ $errors->first('logo') }}</strong>
                    </span>
                  @endif
                </div>

                <label for="job_title" class="col-5 col-form-label text-md-right">Areas of Specialization & Expertise:</label>
                <div class="col-md-7">
                  <select class="form-control" name="category_id">
                    @foreach($categories as $category)
                      <option value="{{$category->id}}">{{$category->name}}</option>
                    @endforeach
                  </select>
                </div>

                <label for="affiliate" class="col-5 col-form-label text-md-right">Affiliations and Membership:</label>
                <div class="col-7">
                <input type="text" name="affiliate" class="form-control">
                </div>
              </div>
            </div>

            <div class="row border border-links py-3 my-3">
              <div class="col-12">
  	      		  <h5 class="text-center text-bold">CONTACT DETAILS</h5>
              </div>
  	      		<div class="form-group row px-3">
        			  <label for="name" class="col-5 col-form-label text-md-right">Name:</label>
        			  <div class="col-7">
        				<input type="text" name="name" class="form-control">
        			  </div>
        			  <label for="name" class="col-5 col-form-label text-md-right">Designation:</label>
        			  <div class="col-7">
        				<input type="text" name="name" class="form-control">
        			  </div>
        			  <label for="name" class="col-5 col-form-label text-md-right">Mobile Number:</label>
        			  <div class="col-7">
        				<input type="text" name="name" class="form-control">
        			  </div>
        			  <label for="name" class="col-5 col-form-label text-md-right">Email:</label>
        			  <div class="col-7">
        				<input type="text" name="name" class="form-control">
        			  </div>
        			  <label for="name" class="col-5 col-form-label text-md-right">Skype ID:</label>
        			  <div class="col-7">
        				<input type="text" name="name" class="form-control">
        			  </div>
        			</div>
            </div>

              <div class="row border border-links py-3 my-3">
        		  <div class="col-6">
    	      		<h6 class="text-center text-bold mb-3">CUSTOMER CARE / TRAINING ISSUES</h6>
    	      		<div class="form-group row">
          			  <label for="name" class="col-5 col-form-label text-md-right">Name:</label>
          			  <div class="col-7">
          				<input type="text" name="name" class="form-control">
          			  </div>
          			  <label for="name" class="col-5 col-form-label text-md-right">Designation:</label>
          			  <div class="col-7">
          				<input type="text" name="name" class="form-control">
          			  </div>
          			  <label for="name" class="col-5 col-form-label text-md-right">Mobile Number:</label>
          			  <div class="col-7">
          				<input type="text" name="name" class="form-control">
          			  </div>
          			  <label for="name" class="col-5 col-form-label text-md-right">Email:</label>
          			  <div class="col-7">
          				<input type="text" name="name" class="form-control">
          			  </div>
          			</div>
        		  </div>

        		  <div class="col-6">
    	      		<h6 class="text-center text-bold mb-3">PAYMENT AND FINANCIAL SETTLEMENT</h6>
    	      		<div class="form-group row">
          			  <label for="name" class="col-5 col-form-label text-md-right">Name:</label>
          			  <div class="col-7">
          				<input type="text" name="name" class="form-control">
          			  </div>
          			  <label for="name" class="col-5 col-form-label text-md-right">Designation:</label>
          			  <div class="col-7">
          				<input type="text" name="name" class="form-control">
          			  </div>
          			  <label for="name" class="col-5 col-form-label text-md-right">Mobile Number:</label>
          			  <div class="col-7">
          				<input type="text" name="name" class="form-control">
          			  </div>
          			  <label for="name" class="col-5 col-form-label text-md-right">Email:</label>
          			  <div class="col-7">
          				<input type="text" name="name" class="form-control">
          			  </div>
          			</div>
        		  </div>
              </div>

              <div class="row border border-links py-3">
        		  <div class="col-6">
    	      		<h6 class="text-center text-bold mb-3">BANKING DETAILS</h6>
    	      		<div class="form-group row">
          			  <label for="name" class="col-5 col-form-label text-md-right">Bank Name:</label>
          			  <div class="col-7">
          				<select name="name" class="form-control">
          					<option>Access Bank Plc</option>
          					<option>Citibank Nigeria Limited</option>
          					<option>Diamond Bank Plc</option>
                    <option>Ecobank Nigeria Plc</option>
                    <option>Fidelity Bank Plc</option>
                    <option>First Bank Nigeria Limited</option>
                    <option>First City Monument Bank Plc</option>
                    <option>Guaranty Trust Bank Plc</option>
                    <option>Heritage Banking Company Ltd</option>
                    <option>Key Stone Bank</option>
                    <option>Polaris Bank</option>
                    <option>Providus Bank</option>
                    <option>Stanbic IBTC Bank Ltd</option>
                    <option>Standard Chartered Bank Nigeria Ltd</option>
                    <option>Sterling Bank Plc</option>
                    <option>SunTrust Bank Nigeria Limited</option>
                    <option>Union Bank of Nigeria Plc</option>
                    <option>United Bank For Africa Plc</option>
                    <option>Unity Bank Plc</option>
                    <option>Wema Bank Plc</option>
                    <option>Zenith Bank Plc</option>
          				</select>
          			  </div>
          			  <label for="name" class="col-5 col-form-label text-md-right">Account Name:</label>
          			  <div class="col-7">
          				<input type="text" name="name" class="form-control">
          			  </div>
          			  <label for="name" class="col-5 col-form-label text-md-right">Account Number:</label>
          			  <div class="col-7">
          				<input type="text" name="name" class="form-control">
          			  </div>
          			</div>
        		  </div>

        		  <div class="col-6">
    	      		<h6 class="text-center text-bold mb-3">HISTORY OF EARNINGS AND PAYMENTS</h6>
    	      		<div class="form-group row">
          			  <label for="name" class="col-5 col-form-label text-md-right">Payment Request:</label>
          			  <div class="col-7">
          				<input type="text" name="name" class="form-control">
          			  </div>
          			  <label for="name" class="col-5 col-form-label text-md-right">Payment Made:</label>
          			  <div class="col-7">
          				<input type="text" name="name" class="form-control">
          			  </div>
          			  <label for="name" class="col-5 col-form-label text-md-right">Current Balance:</label>
          			  <div class="col-7">
          				<input type="text" name="name" class="form-control">
          			  </div>
          			</div>
        		  </div>
              </div>

        		  <div class="col-12 mt-3">
    		  		<input type="submit" name="submit" value="SAVE" class="btn btn-orange btn-block col-2 offset-md-5">
    		  	  </div>
  	      </form>
  	      </div>
  	    </div>
        </div>
      </div>
    </div>
  </section>
<!--/ footer Star /-->
  @include('layouts.footer-copyright')
<!--/ Footer End /-->

</body>
</html>