<aside>
  <div id="sidebar" class="nav-collapse ">
    <!-- sidebar menu start-->
    <ul class="sidebar-menu" id="nav-accordion">
      <p class="centered"><a href="<?php echo e(url('#')); ?>"><img src="<?php echo e(Auth::user()->avatar); ?>" class="avatar"></a></p>
      <h5 class="centered"><?php echo e(Auth::user()->username); ?></h5>

      <?php if(Auth::user()->role_id == 1): ?>
        <li class="sidenav mt current">
          <a class="" href="<?php echo e(route('contractor.dashboard')); ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="sidenav">
          <a href="<?php echo e(route('contractor.profile')); ?>">
            <i class="fa fa-user"></i> <span>Profile</span>
          </a>
        </li>
        <?php if(Auth::user()->status == 1): ?>
        <li class="sidenav">
          <a href="javascript:;">
            <i class="fa fa-building-o"></i> <span>Contractor</span> <i class="fa fa-caret-down down-arrow"></i>
          </a>
          <ul class="sub">
            <li class="sidenav"><a href="<?php echo e(route('contractor.index')); ?>">
            Home</a></li>
            <li class="sidenav"><a href="<?php echo e(route('contractor.dashboard')); ?>">
            View Jobs</a></li>
            <li class="sidenav"><a href="<?php echo e(url('#')); ?>">
            Reviews</a></li>
          </ul>
        </li>
        <?php endif; ?>
        <li class="sidenav">
          <a href="<?php echo e(route('contractor.dashboard')); ?>">
            <i class="fa fa-users"></i> <span>Blog</span>
          </a>
        </li>
        <li class="sidenav">
          <a href="javascript:;">
            <i class="fa fa-money"></i> <span>Earnings</span> <i class="fa fa-caret-down down-arrow"></i>
          </a>
          <ul class="sub">
            <li><a href="<?php echo e(route('contractor.dashboard')); ?>">Payment Request</a></li>
            <li><a href="<?php echo e(route('contractor.dashboard')); ?>">Payment Made</a></li>
            <li><a href="<?php echo e(route('contractor.dashboard')); ?>">Current Balance</a></li>
          </ul>
        </li>

      <?php elseif(Auth::user()->role_id == 2): ?>
        <li class="sidenav mt">
          <a class="active" href="<?php echo e(route('homeowner.dashboard')); ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="sidenav">
          <a href="<?php echo e(route('homeowner.profile')); ?>">
            <i class="fa fa-user"></i> <span>Profile</span>
          </a>
        </li>
         <?php if(Auth::user()->status == 1): ?>
        <li class="sidenav">
          <a href="javascript:;">
            <i class="fa fa-home"></i> <span>Home Owner</span> <i class="fa fa-caret-down down-arrow"></i>
          </a>
          <ul class="sub">
            <li class="sidenav"><a href="<?php echo e(route('homeowner.index')); ?>">
            Home</a></li>
            <li class="sidenav"><a href="<?php echo e(url('#')); ?>">
            Reviews</a></li>
          </ul>
        </li>
        <?php endif; ?>

      <?php elseif(Auth::user()->role_id == 3): ?>
        <li class="sidenav mt">
          <a class="active" href="<?php echo e(route('marketer.dashboard')); ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="sidenav">
          <a href="<?php echo e(route('marketer.profile')); ?>">
            <i class="fa fa-user"></i> <span>Profile</span>
          </a>
        </li>
        <?php if(Auth::user()->status == 1): ?>
        <li class="sidenav">
          <a href="javascript:;">
            <i class="fa fa-shopping-cart"></i> <span>Marketer</span> <i class="fa fa-caret-down down-arrow"></i>
          </a>
          <ul class="sub">
            <li class="sidenav"><a href="<?php echo e(route('marketer.index')); ?>">
            Home</a></li>
            <li class="sidenav"><a href="<?php echo e(url('#')); ?>">
            Reviews</a></li>
          </ul>
        </li>
        <?php endif; ?>

      <?php else: ?>
        <li class="sidenav mt">
          <a class="active" href="<?php echo e(route('trainer.dashboard')); ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="sidenav">
          <a href="<?php echo e(route('trainer.profile')); ?>">
            <i class="fa fa-user"></i> <span>Profile</span>
          </a>
        </li>
        <?php if(Auth::user()->status == 1): ?>
        <li class="sidenav">
          <a href="javascript:;">
            <i class="fa fa-certificate"></i> <span>Trainer</span> <i class="fa fa-caret-down down-arrow"></i>
          </a>
          <ul class="sub">
            <li class="sidenav"><a href="<?php echo e(route('trainer.index')); ?>">
            Home</a></li>
            <li class="sidenav"><a href="<?php echo e(url('#')); ?>">
            Reviews</a></li>
          </ul>
        </li>
        <?php endif; ?>

      <?php endif; ?>   
    </ul>
    <!-- sidebar menu end-->
  </div>
</aside>

<script>
$(document).ready(function() {
    $("#sidebar ul.sidebar-menu li.sidenav").on('click', function() {
      $(this).toggleClass(".current");
    });
  });
</script>



<!--ul.sidebar-menu li a.active-->
<?php /**PATH E:\Laravel - 365home\Homeimprovement\resources\views/layouts/backend/sidebar.blade.php ENDPATH**/ ?>