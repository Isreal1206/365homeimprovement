<aside>
  <div id="sidebar" class="nav-collapse ">
    <!-- sidebar menu start-->
    <ul class="sidebar-menu" id="nav-accordion">
      <p class="centered"><a href="<?php echo e(url('#')); ?>"><img src="<?php echo e(Auth::user()->avatar); ?>" class="avatar"></a></p>
      <h5 class="centered"><?php echo e(Auth::user()->username); ?></h5>
      <li class="mt">
        <a class="active" href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="fa fa-dashboard"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li>
        <a href="<?php echo e(route('admin.profile')); ?>">
          <i class="fa fa-user"></i>
          <span>Profile</span>
        </a>
      </li>
      <li class="sidenav">
        <a href="<?php echo e(route('admin.contractor')); ?>">
          <i class="fa fa-user"></i>
          <span>Contractor</span>
        </a>
      </li>
      <li class="sidenav">
        <a href="<?php echo e(route('admin.category')); ?>">
          <i class="fa fa-list-alt"></i>
          <span>Categories</span>
        </a>
      </li>
      <li class="sub-menu">
        <a href="javascript:;">
          <i class="fa fa-desktop"></i>
          <span>UI Elements</span>
        </a>
        <ul class="sub">
          <li><a href="<?php echo e(url('#')); ?>">General</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Buttons</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Panels</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Font Awesome</a></li>
        </ul>
      </li>
      <li class="sub-menu">
        <a href="javascript:;">
          <i class="fa fa-cogs"></i>
          <span>Components</span>
        </a>
        <ul class="sub">
          <li><a href="<?php echo e(url('#')); ?>">Grids</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Calendar</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Gallery</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Todo List</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Dropzone File Upload</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Inline Editor</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Multiple File Upload</a></li>
        </ul>
      </li>
      <li class="sub-menu">
        <a href="javascript:;">
          <i class="fa fa-book"></i>
          <span>Extra Pages</span>
        </a>
        <ul class="sub">
          <li><a href="<?php echo e(url('#')); ?>">Blank Page</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Login</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Lock Screen</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Profile</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Invoice</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Pricing Table</a></li>
          <li><a href="<?php echo e(url('#')); ?>">FAQ</a></li>
          <li><a href="<?php echo e(url('#')); ?>">404 Error</a></li>
          <li><a href="<?php echo e(url('#')); ?>">500 Error</a></li>
        </ul>
      </li>
      <li class="sub-menu">
        <a href="javascript:;">
          <i class="fa fa-tasks"></i>
          <span>Forms</span>
        </a>
        <ul class="sub">
          <li><a href="<?php echo e(url('#')); ?>">Form Components</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Advanced Components</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Form Validation</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Contact Form</a></li>
        </ul>
      </li>
      <li class="sub-menu">
        <a href="javascript:;">
          <i class="fa fa-th"></i>
          <span>Data Tables</span>
        </a>
        <ul class="sub">
          <li><a href="<?php echo e(url('#')); ?>">Basic Table</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Responsive Table</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Advanced Table</a></li>
        </ul>
      </li>
      <li class="sub-menu">
        <a href="javascript:;">
          <i class=" fa fa-bar-chart-o"></i>
          <span>Charts</span>
        </a>
        <ul class="sub">
          <li><a href="<?php echo e(url('#')); ?>">Morris</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Chartjs</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Flot Charts</a></li>
          <li><a href="<?php echo e(url('#')); ?>">xChart</a></li>
        </ul>
      </li>
      <li class="sub-menu">
        <a href="javascript:;">
          <i class="fa fa-comments-o"></i>
          <span>Chat Room</span>
        </a>
        <ul class="sub">
          <li><a href="<?php echo e(url('#')); ?>">Lobby</a></li>
          <li><a href="<?php echo e(url('#')); ?>"> Chat Room</a></li>
        </ul>
      </li>
      <li>
        <a href="<?php echo e(url('#')); ?>">
          <i class="fa fa-map-marker"></i>
          <span>Google Maps </span>
        </a>
      </li>
    </ul>
    <!-- sidebar menu end-->
  </div>
</aside>



<!--<script>
  $('a').click(function(){
    $('a.active').each(function(){
      $(this).removeClass('active');
    });
    $(this).addClass('active');
  });
</script>--><?php /**PATH C:\Users\DEEONE\Desktop\Homeimprovement-Admin\resources\views/layouts/backend/admin-sidebar.blade.php ENDPATH**/ ?>