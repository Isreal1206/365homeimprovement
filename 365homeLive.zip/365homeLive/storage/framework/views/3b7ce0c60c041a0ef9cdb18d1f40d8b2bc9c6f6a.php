<?php $__env->startSection('heading'); ?>
  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section>
	    <div class="container-fluid intro-banner">	 
       		<div class="row">
       			<div class="col-12 banner-head p-0">
		            <img class="img-responsive img-fluid banner-bg" src="<?php echo e(URL::to('/')); ?>/img/request-quote-banner.jpg" alt="Contractor Page Banner" title="Contractor Banner" style="height: 15vh" />
		        </div>
		    </div>
		</div>

		<div class="container my-5">
			<div class="row">
       			<div class="col-md-12">
		    		<h5>Tell Us what you need and we will connect you with the right professionals</h5>
	            </div>
        		<!-- The left side -->
       		 	<div class="col-md-8 py-3 bg-white">
       		 		<?php if($flash = session('success')): ?>
       		 		<div class="alert alert-success" role="alert">
       		 			<?php echo e($flash); ?>

       		 		</div>
       		 		<?php endif; ?>
       		 		<?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       		 		<form name="form-quote" action="<?php echo e(route('request.store')); ?>" method="POST" enctype="multipart/form-data">
        			<?php echo e(csrf_field()); ?>

		    		<div class="form-group my-3">
		    			<label for="">Category Selected:</label>
				        <input type="text" name="category" id="resulta" class="form-control" readonly>
			        </div>
			        <div class="form-group my-3">
	                	<label for="">State Selected:</label>
			            <input type="text" name="state" id="resultb" class="form-control" readonly>
			        </div>
			       <div class="form-group my-3">
	                	<label for="">LGA Selected:</label>
			            <input type="text" name="lga" id="resultc" class="form-control" readonly>
			        </div>
		            <div class="form-group my-3">
	                	<label for="">When do you need the work to start?</label>
	                	<select id="" name="start_work" class="form-control">
			                <option value="Emergency">Emergency</option>
			                <option value="ASAP, next few days">ASAP, next few days</option>
			                <option value="Next few weeks">Next few weeks</option>
			                <option value="I'm flexible">I'm flexible</option>
			                <option value="Others">Others</option>
			            </select>
			        </div>

			        <div class="form-group my-3">
		            	<label for="">What type of property is this?</label>
	                	<select id="" name="property_type" class="form-control">
		                	<option value="Residential">Residential</option>
		                	<option value="Commercial">Commercial</option>
		            	</select>
		            </div>

		            <div class="form-group my-3">
		            	<label for="">Type of work</label>
	                	<select id="" name="work_type" class="form-control">
			                <option value="New Building">New Building</option>
			                <option value="Renovations">Renovations</option>
			                <option value="Repairs">Repairs</option>
			                <option value="Installation">Installation</option>
			                <option value="Maintenance">Maintenance</option>
			                <option value="Others">Others</option>
		            	</select>
		            </div>

		            <div class="form-group my-3">
		            	<label for="">Budget</label>
	                	<select id="" name="budget" class="form-control">
			                <option value="Under ₦50,000">Under ₦50,000</option>
			                <option value="₦50,000 - ₦500,000">₦50,000 - ₦500,000</option>
			                <option value="₦500,000 - ₦5,000,000">₦500,000 - ₦5,000,000</option>
			                <option value="₦5,000,000 - ₦10,000,000">₦5,000,000 - ₦10,000,000</option>
			                <option value="₦10,000,000 - ₦100,000,000">₦10,000,000 - ₦100,000,000</option>
			                <option value="More than ₦100,000,000">More than ₦100,000,000</option>
			                <option value="Not sure">Not Sure</option>
			            </select>
			        </div>

			        <div class="form-group my-3">
		            	<label for="">What is the status of your job?</label>
	                	<select id="" name="job_status" class="form-control">
		                	<option value="Ready to hire">Ready to hire</option>
		                	<option value="Planning and Budgeting">Planning & Budgeting</option>
		            	</select>
		            </div>

		            <div class="form-group my-3">
		            	<label for="">What is Your Relationship With This Property?</label>
	                	<select id="" name="property_relation" class="form-control">
		                	<option value="I own it">I Own It</option>
		                	<option value="I rented it">I Rented It</option>
		                	<option value="I am considering Buying It">I am considering Buying It</option>
		            	</select>
		            </div>

		             <div class="form-group my-3">
		            	<label for="">Describe what you need done</label>
		            	<textarea name='description' id="" class="form-control" rows= "6"></textarea>
		            </div>

		            <div class="form-group row my-3 px-3">
		            	<p class="col-12 col-sm-12 col-md-12 col-lg-12 bg-warning pl-2"><small>Image size should not be more than 2MB</small></p>
		            	<label for="photo" class="col-12 col-sm-12 col-md-4 col-lg-4 px-0">Attach a Plan, Photo etc:</label>
		            	<div class="col-12 col-sm-12 col-md-8 col-lg-8 pl-0">
							<input type="file" class="form-control-file btn-sm p-0 mb-0" name="file" aria-describedby="fileHelpId">
						</div>
	                </div>

	                <div class="form-group text-danger mt-5">
	                	<div class="alert alert-success">
							<span>Phones & Email are used to provide free estimates</span>
						</div>
					</div>

	                <div class="form-group my-3">
	                	<label for="">How Should We Contact You?</label>
	                	<input type="text" name="name" placeholder="Name" class="form-control mb-3">
						<input type="text" name="address" placeholder="Physical Address" class="form-control my-3">
						<input type="email" name="email" placeholder="Email Address" class="form-control my-3">
						<input type="text" name="mobile" placeholder="Mobile Number" class="form-control my-3">
						<input type="text" name="office_no" placeholder="Office Number" class="form-control my-3">
					</div>

		            <div class="form-group my-3">
		            	<label for="">Select Number of Bids:</label>
	                	<select id="" name="bid_no" class="form-control">
	                		<option value="3">How Many Bids / Expression of interest Do You Want From Contractors?</option>
		                	<option value="3">3</option>
		                	<option value="7">7</option>
		                	<option value="10">10</option>
		            	</select>
		            </div>

		            <div class="form-group my-2">
						<label for="time">Best Time to Contact You:</label>
						<select id="time" name="contact_time" class="form-control">
		                	<option value="Morning">Morning</option>
		                	<option value="Afternoon">Afternoon</option>
		                	<option value="Evening">Evening</option>
		                	<option value="Night">Night</option>
		            	</select>
					</div>
		            
					 <div class="form-group my-3">
					 	<button type="submit" name="getQuote" id="" class="btn btn-orange my-3">Get Quotes</button>
	               
					</div>
					</form>
		        </div>

		        <!-- The right side -->
		           
		        <div class="col-md-3 offset-md-1 py-2"> 
	        		<h6>HOW IT WORKS</h6>
	        		<p>Step 1:</p>
	        		<p>Fill in the form so we get a better idea of what you need help with.</p>
	        		<hr>
	        		<p>Step 2:</p>
	        		<p>We will notify our database of trade business and get back to you via email you provided.</p>
	        		<hr>
	        		<p>Step 3:</p>
	        		<p>You chose the best tradie from the list of options provided.</p>
	            </div>
	        </div>
	    </div>
	</section>

    <?php echo $__env->make('layouts.footer-copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script type="text/javascript">
	document.getElementById("resulta").value = localStorage.getItem('catQuote');
	document.getElementById("resultb").value = localStorage.getItem('stateQuote');
	document.getElementById("resultc").value = localStorage.getItem('lgaQuote');
	</script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.app-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DEEONE\Desktop\Homeimprovement\resources\views/links/request-quote.blade.php ENDPATH**/ ?>