<?php $__env->startSection('heading'); ?>
  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section class="bg-links pb-5">
    <div class="container-fluid p-0">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <div class="banner-head mb-0">
            <img class="img-responsive img-fluid banner-bg" src="<?php echo e(URL::to('/')); ?>/img/page-banner.jpg" alt="Page Banner"/>
            <div class="banner-overlay2">
              <h1 class="text-white text-title" style="margin-top: 6rem">Become a <span class="text-orange">Trainer</span></h1>
              <h6 class="text-center text-white">@</h6>
              <p class="text-center text-primary">Hausworth Nigeria Limited</p>
              <p class="text-center"><a href="<?php echo e(route('register')); ?>" class="btn btn-sm btn-orange font-w-6">signup now</a></p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <div class="alert alert-dark mt-3 mb-5">
            <span class="mr-2"><a href="<?php echo e(url('/')); ?>">Home</a></span>
            <i class="fa fa-angle-double-right"></i>
            <span class="mx-2"><a href="<?php echo e(url('#')); ?>">Training</a></span>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h3 class="text-title mb-4">BECOME A TRAINER</h3>
          <p class="text-jusify">Hausworth Nigeria Limited owners of 365 home improvements seeks human resource development firms in different areas of home improvement with a view towards working with them in the provision of quality training services to our users.</p>
        </div>
      </div>
        
      <div class="row my-5">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h4 class="text-center mb-4"> BENEFITS OF BECOMING A TRAINER</h4>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
          <img src="img/bg-img/money.jpg" alt="Earnings_Image" width ="600px" height="400px">
          <p class="text-center">MORE EARNINGS</p>
          <p class="text-justify">Training company and trainer’s earns seventy percent (70%) of the cost price of the subscription on our platform. We take care of all the marketing and earn thirty percent (30%).</p>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
          <img src="img/bg-img/market.jpg" alt="Marketing_Image"  width ="600px" height="400px">
          <p class="text-center">GREATER MARKETING AND PUBLICITY</p>
          <p class="text-justify">Hausworth Nigeria Limited would ensure maximum marketing and publicity of your trainings on different platforms both online and offline.
          Because we work with other training providers specializing in the different areas of interest, we would be able to attract different subscribers with possible interest in your contents.</p>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
          <img src="img/bg-img/payment.jpg" alt="Payment_Image" width ="600px" height="400px">
          <p class="text-center">PAYMENT</p>
          <p class="text-justify">The amount earned can be easily seen along with your payment and earning history (transaction history).
          The payment would be remitted upon completion of the training. Payment would be made into your account directly.
          In order to become a training provider on our platform, please do provide us with the following details</p>
        </div>
      </div>

      <div class="row mt-5">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h4 class="text-title text-left mb-2">Latest trainings</h4>
          <div class="line-title-15"></div>
        </div>
      </div>
      <div class="row mt-5">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-9">
          <div class="bg-white box-shadow-custom border-radius-custom">
            <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row p-3">
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <a href ="#"><img src="/img/bg-img/training-banner.jpg" class="img-responsive img-fluid height-100 border-radius-custom" alt="Image"></a>
              </div>
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-9">
                <a href="#"><h5 class="text-bold text-orange mb-0"><?php echo e($trainer->organization); ?></h5></a>
                <span class="text-muted"><?php echo e($trainer->created_at->format ('M, d Y.')); ?> <?php echo e($trainer->firstname); ?> <?php echo e($trainer->lastname); ?></span>
                <p class="text-justify text-black mb-0"><i class="fa fa-map-marker mr-1"> <?php echo e($trainer->address); ?> <?php echo e($trainer->city); ?>.</i></p>
                 <span class="text-orange"><i class="text-muted fa fa-building-o"> <?php echo e($trainer->job_title->name); ?></i></span>
              </div>
            </div>
            <div class="dropdown-divider"></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
        <?php if($flash = session('newsletter')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e($flash); ?>

          </div>
          <?php endif; ?>
          <div class="bg-white box-shadow-custom border-radius-custom p-2">
            <p class="text-bold text-center mb-0">Newsletter Subscription</p>
            <div class="dropdown-divider"></div>
            <form method="post" action="<?php echo e(route('newsletter.store')); ?>" role="form">
              <?php echo e(csrf_field()); ?>

              <div class="pt-2">
                <input type="text" name="name" placeholder="Name" class="form-control">
                <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
              </div>

              <div class="py-3">
                <input type="text" name="mobile" placeholder="Telephone" class="form-control">
                <small class="text-danger"><?php echo e($errors->first('mobile')); ?></small>
              </div>

              <div class="pb-3">
                <input type="email" name="email" placeholder="Email Address" class="form-control">
                <small class="text-danger"><?php echo e($errors->first('email')); ?></small>
              </div>

              <input type="submit" class="btn btn-block btn-orange text-uppercase" value="Subscribe">

              <small class="text-justify">
              I agree to the <a class="text-primary" target="_blank" href="<?php echo e(route('tos')); ?>">Terms of Use</a> and <a class="text-primary" target="_blank" href="<?php echo e(route('privacy')); ?>">Privacy Policy.</a></small>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <?php echo $__env->make('layouts.footer-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DEEONE\Desktop\Laravel - 365home Ipage\Homeimprovement\resources\views/links/training/index.blade.php ENDPATH**/ ?>