<?php $__env->startSection('heading'); ?>
  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section>
    <div class="container-fluid p-0">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <div class="banner-head">
            <img class="img-responsive img-fluid banner-bg" src="<?php echo e(URL::to('/')); ?>/img/page-banner.jpg" alt="Page Banner"/>
            <div class="banner-overlay pb-0">
            <h1 class="text-white text-center" style="font-size: 1.4rem; font-weight: 700">NEWS <span class="text-orange">AND </span>PRESS RELEASE</h1>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <div class="alert alert-danger mt-3 mb-5">
            <span class="mr-2"><a href="<?php echo e(url('/')); ?>" class="text-black">Home</a></span>
            <i class="fa fa-angle-double-right text-black"></i>
            <span class="mx-2"><a href="<?php echo e(url('#')); ?>" class="text-black">News and Press Release</a></span>
          </div>
        </div>
        
        <div class="col-12 col-sm-12 col-md-12 col-lg-8 mb-5">
          <p>Get Access to the very latest news and press release from 365homeimprovement.</p>
          <div class="card border-light box-shadow p-3">
            <div class="news-img mb-3">
              <img class="img-responsive d-block" width="100%" src="<?php echo e(URL::to('/')); ?>/img/post-single.jpg" alt=""/>
            </div>
            <div class="text-center mb-3 text-uppercase">
              <h4 class="text-bold">Fast and Accurate Bids For Leads</h4>
            </div>
            <div class="news-content text-justify">
              <p>You have a small team or own a large company, having a constant stream of high-quality prospects is the key to maintaining a consistent cash flow and a healthy business.</p>

              <p>The challenge is – where are your customers? What’s the best way to get in front of them when they’re looking for a home improvement contractor?</p>

              <p>Most of today’s consumers search for local service providers online. They’d find the name of a few local contractors on Google, read some online reviews, visit their websites, and request a quote.</p>

              <p>The key to getting found by prospects is to make sure that your website shows up on the first page of relevant local search results.</p>

              <p>Unfortunately, many home improvement contractors fall behind in their prospecting efforts because they don’t have the time and resources to spend on online marketing.</p>

              <p>Thankfully, there are many lead generation services to which you can outsource your marketing activities.</p>

              <p>Some of these vendors drive traffic to your website, on which potential clients submit their inquiries.</p>

              <p>Others use online marketing techniques to attract prospects to their platforms, on which the visitors submit project details. These vendors will then verify the leads and sell them to contractors.</p>
            </div>
            <div class="news-footer">
              <p class="news-date"><i class="fa fa-calendar"></i> <strong>Date of Publication:</strong> April 4, 2019.</p>
              <p class="news-tag"><i class="fa fa-tags"></i> <strong>Tag(s): </strong> <span class="badge badge-secondary py-1 px-2"> Leads </span> </p>
            </div>
          </div>
        </div>

        <div class="col-12 col-sm-12 col-md-12 col-lg-4 mb-5">

          <div class="card box-shadow py-2">
            <p class="title-sub mb-0">Latest Articles</p>

            <div class="dropdown-divider"></div>
            
            <a class="np-articles px-4 text-black" href="<?php echo e(url('#')); ?>">Finding the right contractor is fast, easy and free!</a>

            <div class="dropdown-divider"></div>

            <a class="np-articles px-4 text-black" href="<?php echo e(url('#')); ?>">Best Way to Design your Home</a>

            <div class="dropdown-divider"></div>

            <a class="np-articles px-4 text-black" href="<?php echo e(url('#')); ?>">NAF loses airman in parachuting accident in Kaduna</a>

            <div class="dropdown-divider"></div>

            <a class="np-articles px-4 text-black" href="<?php echo e(url('#')); ?>">Subscribe to our Newsletter Report</a>
            
            <div class="dropdown-divider"></div>

            <a class="np-articles px-4 text-black" href="<?php echo e(url('#')); ?>">Online Marketing Techniques</a>

            <div class="dropdown-divider"></div>

            <a class="np-articles px-4 text-black" href="<?php echo e(url('#')); ?>">FG slashes unity schools’ tuition fees</a>

            <div class="dropdown-divider"></div>

            <a class="np-articles px-4 text-black" href="<?php echo e(url('#')); ?>">Nigerian Women Warned Not To Come To Britain In Government Campaign</a>

            <div class="dropdown-divider"></div>

            <a class="np-articles px-4 text-black" href="<?php echo e(url('#')); ?>"> How To Become President Without WAEC Certificate - Festus Keyamo</a>

            <div class="dropdown-divider"></div>

            <a class="np-articles px-4 text-black" href="<?php echo e(url('#')); ?>">Get real-time updates about local jobs</a>

            <div class="dropdown-divider"></div>

            <a class="np-articles px-4 text-black" href="<?php echo e(url('#')); ?>">Discover how 365homeimprovement can help your business grow</a>

            <div class="dropdown-divider"></div>

            <a class="np-articles px-4 text-black" href="<?php echo e(url('#')); ?>">Find answers to basic questions about 365homeimprovement</a>

            <div class="dropdown-divider"></div>

            <a class="np-articles px-4 text-black" href="<?php echo e(url('#')); ?>">Get the Best Quotes from our Contractors</a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <?php echo $__env->make('layouts.footer-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DEEONE\Desktop\Homeimprovement-User&Admin\resources\views/links/news-and-press-release.blade.php ENDPATH**/ ?>