<!DOCTYPE html>
<html lang="en">

<head>
  <!--header start-->
  <?php echo $__env->make('layouts.backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!--header end-->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--navbar start-->
    <?php echo $__env->make('layouts.backend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--navbar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <?php echo $__env->make('layouts.backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="row content-panel">
              <div class="profile-text">
                <h3>Start Selling</h3>
              </div>
              <!-- /panel-heading -->
              <div class="panel-body">
                <div class="tab-content">
                  <!-- /tab-pane -->
                  <div id="edit" class="tab-pane active">
                    <div class="row site-min-height">
                      <div class="col-lg-8 col-lg-offset-2 detailed">
                        <h4 class="mb">Upload Products</h4>
                        
                        <?php if($flash = session('success')): ?>
                          <div class="alert alert-success" role="alert">
                            <?php echo e($flash); ?>

                          </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('marketer.products')); ?>" role="form" class="form-horizontal" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                          <input type="hidden" value="<?php echo e($marketer->marketer_id); ?>" class="form-control" name="marketer_id">
                        </div>

                        <div class="form-group">
                          <label class="col-lg-3 control-label">Product name</label>
                          <div class="col-lg-7">
                            <input type="text" id="" class="form-control" name="name">
                            <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="col-lg-3 control-label">Category:</label>
                          <div class="col-lg-7">
                            <select id="category" name="category" class="form-control" onclick="populate('category','sub_category')" readonly>
                              <option value="<?php echo e($marketer->category); ?>"> <?php echo e($marketer->category); ?> </option>
                            </select>
                            <small class="text-danger"><?php echo e($errors->first('category')); ?></small>
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="col-lg-3 control-label">Sub Category:</label>
                          <div class="col-lg-7">
                            <select id="sub_category" name="subcategory" class="form-control">
                              <option selected="selected">Click on the Category field above before Selecting</option>
                              
                            </select>
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="col-lg-3 control-label">Description</label>
                          <div class="col-lg-7">
                            <textarea name ="description" class ="form-control" rows="4" placeholder="Give us brief details about your products and also include damage policy, warranty"></textarea>
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="col-lg-3 control-label">Product Price</label>
                          <div class="col-lg-7">
                            <input type="text" id="" class="form-control" name="price">
                            <small class="text-danger"><?php echo e($errors->first('price')); ?></small>
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="col-lg-3 control-label">manufacturer</label>
                          <div class="col-lg-7">
                            <input type="text" id="" class="form-control" name="manufacturer">
                            <small class="text-danger"><?php echo e($errors->first('manufacturer')); ?></small>
                          </div>
                        </div>
                        
                        <div class="form-group">
                          <label class="col-lg-3 control-label">return policy</label>
                          <div class="col-lg-7">
                            <input type="text" id="" class="form-control" name="policy">
                            <small class="text-danger"><?php echo e($errors->first('policy')); ?></small>
                          </div>
                        </div>

                         <div class="form-group">
                          <label class="col-lg-3 control-label">Number Available</label>
                          <div class="col-lg-7">
                            <input type="number" id="" class="form-control" name="available">
                            <small class="text-danger"><?php echo e($errors->first('available')); ?></small>
                          </div>
                        </div>
                          
                        <div class="form-group">
                          <label class="control-label col-lg-7 col-lg-offset-3 text-danger"><small>Upload Image with file size not more than 2MB</small></label>
                          <label class="col-lg-3 control-label">Product image:</label>
                          <div class="col-lg-7">
                            <input type="file" id="products1" class="file-pos" name="image_file">
                            <small class="text-danger"><?php echo e($errors->first('image_file')); ?></small>
                          </div>
                        </div>
                        
                        <div class="form-group">
                          <div class="col-lg-offset-3 col-lg-7">
                            <button class="btn btn-theme" type="submit">Save</button>
                            <button class="btn btn-theme04" type="reset">Cancel</button>
                          </div>
                        </div>
                        </form>

                        <h4 class="mt-100">Display Products</h4>
                        
                        <?php if(count($products) > 0): ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="col-lg-4 height-200 border-custom">
                            <img src="<?php echo e($product->image_file); ?>" class="img-responsive img-fluid">
                            <p><?php echo e($product->name); ?></p>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </div>
                      <!-- /col-lg-8 -->
                    </div>
                    <!-- /row -->
                  </div>
                  <!-- /tab-pane -->
                </div>
                <!-- /tab-content -->
              </div>
              <!-- /panel-body -->
            </div>
            <!-- /col-lg-12 -->
          </div>
          <!-- /row -->
        </div>
        <!-- /container -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    
    <!--footer start-->
    <?php echo $__env->make('layouts.backend.footer-copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--footer end-->
  </section>

  <!-- js placed at the end of the document so the pages load faster -->
  <?php echo $__env->make('layouts.backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\DEEONE\Desktop\Laravel - 365home Ipage\365homeimprovement\resources\views/user/marketers/upload-product.blade.php ENDPATH**/ ?>