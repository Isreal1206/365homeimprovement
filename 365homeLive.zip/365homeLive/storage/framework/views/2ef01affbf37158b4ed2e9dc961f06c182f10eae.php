<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="Dashboard">
<meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
<title><?php echo e(config('app.name')); ?></title>

<!-- Favicons -->
<link href="/img/365Logo.png" rel="icon">
<link href="/img/apple-touch-icon.png" rel="apple-touch-icon">

<!-- Bootstrap core CSS -->
<link href="/backend/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--external css-->
<link href="/backend/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="/backend/css/zabuto_calendar.css">
<link rel="stylesheet" type="text/css" href="/backend/lib/gritter/css/jquery.gritter.css" />
<!-- Custom styles for this template -->
<link href="/backend/css/style.css" rel="stylesheet">
<link href="css/app.css" rel="stylesheet">
<link href="/backend/css/style-responsive.css" rel="stylesheet">
<script src="/backend/lib/chart-master/Chart.js"></script><?php /**PATH C:\Users\DEEONE\Desktop\Homeimprovement\resources\views/layouts/backend/admin-header.blade.php ENDPATH**/ ?>