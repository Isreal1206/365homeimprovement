<?php $__env->startSection('heading'); ?>
  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section>
    <div class="container-fluid p-0">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <div class="banner-head">
            <img class="img-responsive img-fluid banner-bg" src="<?php echo e(URL::to('/')); ?>/img/page-banner.jpg" alt="Page Banner"/>
            <div class="banner-overlay pb-0">
            <h1 class="text-white text-center" style="font-size: 1.4rem; font-weight: 700">GET <span class="text-orange">NEWSLETTER </span>FROM 365HOMEIMPROVEMENT</h1>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="row mb-5">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <div class="alert alert-danger mt-3 mb-5">
            <span class="mr-2"><a href="<?php echo e(url('/')); ?>">Home</a></span>
            <i class="fa fa-angle-double-right"></i>
            <span class="mx-2"><a href="<?php echo e(url('#')); ?>">Newsletter</a></span>
          </div>
        </div>
        
        <div class="col-12 col-sm-12 col-md-6 col-lg-6 mx-auto">
          <p class="text-center">Join 365homeimprovement Newsletter today and never miss out on new updates from our website.</p>
          
          <?php if($flash = session('success')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e($flash); ?>

          </div>
          <?php endif; ?>
          <div class="card box-shadow py-3">
            <h4 class="title-sub">Enter Your Details</h4>

            <div class="dropdown-divider"></div>
            
            <form method="post" action="<?php echo e(route('newsletter.store')); ?>" role="form">
              <?php echo e(csrf_field()); ?>


            <div class="px-3">
              <div class="pt-2">
                <input type="text" name="name" placeholder="Name" class="form-control">
                <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
              </div>

              <div class="py-3">
                <input type="text" name="mobile" placeholder="Telephone" class="form-control">
                <small class="text-danger"><?php echo e($errors->first('mobile')); ?></small>
              </div>

              <div class="pb-3">
                <input type="email" name="email" placeholder="Email Address" class="form-control">
                <small class="text-danger"><?php echo e($errors->first('email')); ?></small>
              </div>

              <p class="text-justify">
              By clicking the subscribe button, you acknowledge and agree to the <a class="text-primary" target="_blank" href="<?php echo e(route('tos')); ?>">Terms of Use</a> and <a class="text-primary" target="_blank" href="<?php echo e(route('privacy')); ?>">Privacy Policy.</a></p>

              <input type="submit" class="btn btn-orange text-uppercase" name="nlSubmit" value="Subscribe">

            </div>
            </form>
          </div> 
        </div>
      </div>
    </div>
  </section>

  <?php echo $__env->make('layouts.footer-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DEEONE\Desktop\Homeimprovement-Admin\resources\views/links/newsletter.blade.php ENDPATH**/ ?>