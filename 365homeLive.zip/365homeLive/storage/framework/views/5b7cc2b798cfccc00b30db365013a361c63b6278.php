<?php $__env->startSection('heading'); ?>
  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section class="bg-links py-5" style="margin-top: 4.2rem">
    <?php if(count($contractors)>0): ?>
    <div class="container-fluid">
      <div class="row border mb-5 bg-white">
        <h3 class="py-2 px-5"><?php echo e($categories->name); ?></h3>
      </div> <!-- end of row-->
    </div>

    <div class="container vheight">
      <?php $__currentLoopData = $contractors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contractor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row bg-white py-3">
        <div class="col-12 col-sm-12 col-md-12 col-lg-2">
          <img src="<?php echo e($contractor->banner); ?>" class="img-responsive img-fluid w-100 height-100 border-radius-custom" />
        </div>
        <div class="col-12 col-sm-12 col-md-12 col-lg-10">
          <h3><?php echo e($contractor->company_name); ?></h3>
          <p><?php echo substr($contractor->description, 0, 70); ?><?php echo strlen($contractor->description) > 60 ? "..." : ""; ?> <small><a href="/contractors/<?php echo e($contractor->contractor_id); ?>" class="text-primary"> Read More</a></small></p>
          <p>
            <small><i class="fa fa-map-marker mr-1"></i><?php echo e($contractor->address); ?> <?php echo e($contractor->state); ?></small>
          </p>
        </div>
      </div>
      <div class="dropdown-divider"></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php else: ?>
    <div class="row border mb-3 bg-white mtop">
      <h3 class="py-2 px-5"><?php echo e($categories->name); ?></h3>
    </div> <!-- end of row-->
    
    <div class="container vheight">
      <p class="text-center text-danger">No Record Available Yet!</p>
    </div>
    <?php endif; ?>
  </section>
  <?php echo $__env->make('layouts.footer-copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DEEONE\Desktop\Laravel - 365home Ipage\365homeimprovement\resources\views/links/categories/template.blade.php ENDPATH**/ ?>