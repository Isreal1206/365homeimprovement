<!DOCTYPE html>
<html lang="en">

<head>
  <!--header start-->
  <?php echo $__env->make('layouts.backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!--header end-->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--navbar start-->
    <?php echo $__env->make('layouts.backend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--navbar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <?php echo $__env->make('layouts.backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <div class="row site-min-height">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <?php $__currentLoopData = $contractors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contractor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="row content-panel">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="panel-heading">
                  <ul class="nav nav-tabs nav-justified">
                    <li class="active">
                      <a data-toggle="tab" href="#edit">Edit Contractor</a>
                    </li>
                    <li>
                      <a data-toggle="tab" href="#contact" class="contact-map">Contact</a>
                    </li>
                    <li>
                      <a data-toggle="tab" href="#overview">Overview</a>
                    </li>
                  </ul>
                </div>
                <!-- /panel-heading -->
                <div class="panel-body">
                  <div class="tab-content">
                    <div id="edit" class="tab-pane  active">
                      <div class="row site-min-height">
                        <div class="col-md-10 col-md-offset-1 detailed mt">
                          <?php if($flash = session('contractor_update')): ?>
                            <div class="alert alert-success text-center" role="alert">
                              <i class="fa fa-check"></i> <?php echo e($flash); ?>

                            </div>
                          <?php endif; ?>
                          <form method="POST" action="<?php echo e(route('contractor.update')); ?>" role="form" enctype="multipart/form-data" class="form-horizontal col-md-12">
                          <?php echo e(csrf_field()); ?>

                          <div class="form-group">
                            <label class="col-lg-3 control-label">Banner:</label>
                            <div class="col-lg-9">
                              <input id="company_logo" class="file-pos" type="file" name="logo">
                              <small class="text-danger"><?php echo e($errors->first('logo')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Firstname:</label>
                            <div class="col-lg-9">
                              <input id="firstname" class="form-control" placeholder="<?php echo e($contractor->firstname); ?>" type="text" name="firstname">
                              <small class="text-danger"><?php echo e($errors->first('firstname')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Lastname:</label>
                            <div class="col-lg-9">
                              <input id="lastname" class="form-control" placeholder="<?php echo e($contractor->lastname); ?>" type="text" name="lastname">
                              <small class="text-danger"><?php echo e($errors->first('lastname')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Email:</label>
                            <div class="col-lg-9">
                              <input id="slug" class="form-control" placeholder="<?php echo e($contractor->email); ?>" type="text" name="slug"readonly>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Name of Organization:</label>
                            <div class="col-lg-9">
                              <input id="company_name" class="form-control" placeholder="<?php echo e($contractor->company_name); ?>" type="text" name="company_name">
                              <small class="text-danger"><?php echo e($errors->first('company_name')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Job Category:</label>
                            <div class="col-lg-9">
                              <input id="job_category" class="form-control" placeholder="<?php echo e($contractor->job_category->name); ?>" type="text" name="job_category" readonly>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Slug:</label>
                            <div class="col-lg-9">
                              <input id="slug" class="form-control" value="<?php echo e($contractor->job_category->slug); ?>-<?php echo e($contractor->id); ?>" type="text" name="slug" readonly>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Mobile Number:</label>
                            <div class="col-lg-9">
                              <input id="mobile_no" class="form-control" placeholder="<?php echo e($contractor->mobile_no); ?>" type="text" name="mobile_no">
                              <small class="text-danger"><?php echo e($errors->first('mobile_no')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Office Number:</label>
                            <div class="col-lg-9">
                              <input id="office_no" class="form-control" placeholder="<?php echo e($contractor->office_no); ?>" type="text" name="office_no">
                              <small class="text-danger"><?php echo e($errors->first('office_no')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Address:</label>
                            <div class="col-lg-9">
                              <input id="address" class="form-control" placeholder="<?php echo e($contractor->address); ?>" type="text" name="address">
                              <small class="text-danger"><?php echo e($errors->first('address')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Title Content:</label>
                            <div class="col-lg-9">
                              <input id="desc_title" class="form-control" placeholder="<?php echo e($contractor->desc_title); ?>" type="text" name="desc_title">
                              <small class="text-danger"><?php echo e($errors->first('desc_title')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Content:</label>
                            <div class="col-lg-9">
                              <textarea rows="7" cols="20" id="article-ckeditor" class="form-control" name="description"><?php echo $contractor->description; ?></textarea>
                              <small class="text-danger"><?php echo e($errors->first('description')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <div class="col-lg-offset-3 col-lg-9">
                              <button class="btn btn-theme" type="submit">Save</button>
                              <button class="btn btn-theme04" type="reset">Reset</button>
                            </div>
                          </div>
                          </form>
                        </div>
                        <!-- /col-lg-8 -->
                      </div>
                      <!-- /row -->
                    </div>
                    <!-- /tab-pane -> EDIT -->

                    <div id="contact" class="tab-pane">
                      <div class="row site-min-height">
                        <div class="col-md-6">
                          <div id="map"></div>
                        </div>
                        <!-- /col-md-6 -->
                        <div class="col-md-6 detailed">
                          <h4>Location</h4>
                          <div class="col-md-8 col-md-offset-2 mt mb">
                            <p><strong>Address:</strong> <?php echo e($contractor->address); ?></p>
                          </div>
                          <h4>Contacts</h4>
                          <div class="col-md-8 col-md-offset-2 mt">
                            <p><strong>Mobile Number:</strong> <?php echo e($contractor->mobile_no); ?></p>
                            <p><strong>Office Number:</strong> <?php echo e($contractor->office_no); ?></p>
                            <p><strong>Email:</strong> <?php echo e($contractor->email); ?></p>
                          </div>
                        </div>
                        <!-- /col-md-6 -->
                      </div>
                      <!-- /row -->
                    </div>
                    <!-- /tab-pane -> CONTACT-->

                    <div id="overview" class="tab-pane">
                      <div class="row site-min-height">
                        <div class="col-md-10 col-md-offset-1 detailed">
                          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4 pull-right mt">
                            <img src="<?php echo e($contractor->logo); ?>" alt="Logo" class="img-responsive img-fluid border-custom border-radius-custom height-200">
                          </div>
                          <!-- detailed -->
                          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 table-responsive mt">
                            <table class="table table-striped">
                            <tr>
                              <th width="30%">CONTRACTOR NAME:</th>
                              <td width="70%"><?php echo e($contractor->firstname); ?> <?php echo e($contractor->lastname); ?></td>
                            </tr>

                            <tr>
                              <th>COMPANY NAME:</th>
                              <td><?php echo e($contractor->company_name); ?></td>
                            </tr>

                            <tr>
                              <th>JOB CATEGORY:</th>
                              <td><?php echo e($contractor->job_category->name); ?></td>
                            </tr>

                            <tr>
                              <th>SLUG:</th>
                              <td><?php echo e($contractor->slug); ?></td>
                            </tr>

                            <tr>
                              <th>TITLE CONTENT:</th>
                              <td><?php echo e($contractor->desc_title); ?></td>
                            </tr>

                            <tr>
                              <th>CONTENT:</th>
                              <td><?php echo $contractor->description; ?></td>
                            </tr>
                            </table>
                          </div>
                          <!-- /detailed -->
                        </div>
                        <!-- /col-md-12 -->
                      </div>
                      <!-- row -->
                    </div>
                    <!-- /tab-pane -> OVERVIEW -->
                  </div>
                  <!-- /tab-content -->
                </div>
                <!-- /panel-body -->
                </div>
                <!-- /col-12 -->
              </div>
              <!-- /row content-panel -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <!-- /col-lg-12 -->
        </div>
        <!-- /row -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->

    <!--footer start-->
    <?php echo $__env->make('layouts.backend.footer-copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--footer end-->
  </section>

  <!-- js placed at the end of the document so the pages load faster -->
  <?php echo $__env->make('layouts.backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
  <script>
    CKEDITOR.replace( 'article-ckeditor' );
  </script>

</body>

</html>
<?php /**PATH C:\Users\DEEONE\Desktop\Homeimprovement\resources\views/user/contractors/contractor.blade.php ENDPATH**/ ?>