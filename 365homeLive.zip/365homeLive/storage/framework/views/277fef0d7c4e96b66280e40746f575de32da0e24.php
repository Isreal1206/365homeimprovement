<?php $__env->startSection('heading'); ?>
  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section class="bg-links pb-5">
    <div class="container-fluid p-0">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <div class="banner-head mb-0">
            <img class="img-responsive img-fluid banner-bg" src="<?php echo e(URL::to('/')); ?>/img/page-banner.jpg" alt="Page Banner"/>
            <div class="banner-overlay2">
              <h1 class="text-white text-title mb-1" style="margin-top: 4.5rem">Become a <span class="text-orange">Writer</span></h1>
              <pre class="text-center text-white mb-0">Publish articles, reviews, and guides and share them with the world.</pre> 
              <pre class="text-center text-white">Create and build a niche community.</pre>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container mb-5">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <div class="alert alert-dark mt-3 mb-5">
            <span class="mr-2"><a href="<?php echo e(url('/')); ?>">Home</a></span>
            <i class="fa fa-angle-double-right"></i>
            <span class="mx-2"><a href="<?php echo e(url('blog')); ?>">Blog</a></span>
            <i class="fa fa-angle-double-right"></i>
            <span class="mx-2"><a href="<?php echo e(url('#')); ?>">Create Article</a></span>
          </div>
        </div>
      </div>

      <div class="row mb-5">
        <div class="col-lg-6 offset-lg-3 bg-white p-3">
          <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <form action="<?php echo e(route('create.article.submit')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

            <h4  class ="text-subtitle mb-3">Section One: Personal Information</h4>
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Full Names" name="fullnames">
            </div>

            <div class="form-group">
              <input type="text" class="form-control" placeholder="Email" name="email">
            </div>

            <div class="form-group">
              <p> <small> Please upload your picture: (Maximum Upload Size: 2MB)</small> </p>
              <div class="input-group">
                <input type="file" accept="image/png, image/jpeg, image/gif" name="avatar" class ="mb-3"/>
              </div>
            </div>
           
            <h4 class ="text-subtitle mb-3">Section Two: Article Information</h4>

            <div class="form-group">
              <select id="" class="form-control" name="category">
                <option value="">-- Select Category --</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="form-group">
              <input type="text" class="form-control" placeholder="Title" name="title">
            </div>
            
            <div class="form-group">
              <textarea name="body" id="article-ckeditor" class="form-control" rows="7" placeholder="Start Writing"></textarea>
            </div>

            <div class="form-group">
              <p> <small>Attachment: (Maximum Upload Size: 2MB)</small> </p>
              <div class="input-group">
                <input type="file" accept="image/png, image/jpeg, image/gif" name="image_file"/>
              </div>
            </div>

            <button type="submit" class="btn btn-orange my-3">Submit Article</button>
          </form>
        </div>
      </div>
    </div>    
  </section>
 <?php echo $__env->make('layouts.footer-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.app-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DEEONE\Desktop\Laravel - 365home Ipage\365homeimprovement\resources\views/links/blog/create-article.blade.php ENDPATH**/ ?>