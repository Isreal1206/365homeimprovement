<!DOCTYPE html>
<html lang="en">

<head>
  <!--header start-->
  <?php echo $__env->make('layouts.backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!--header end-->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--navbar start-->
    <?php echo $__env->make('layouts.backend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--navbar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <?php echo $__env->make('layouts.backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 main-chart">
            <!--CUSTOM CHART START -->
            <div class="row mt">
              <div class="col-lg-10 col-md-offset-1">
                <?php if($flash = session('trainer_register')): ?>
                  <div class="alert alert-success text-center mb" role="alert">
                    <i class="fa fa-check"></i> <?php echo e($flash); ?>

                  </div>
                <?php endif; ?>
                <?php if($flash = session('verify')): ?>
                  <div class="alert alert-success text-center mb" role="alert">
                    <i class="fa fa-check"></i> <?php echo e($flash); ?>

                  </div>
                <?php endif; ?>
              </div>
              <!--/ col-md-6 -->
              <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 mb">
                <div class="panel-box">
                  <p class="banner">365Homeimprovement</p>
                  <i class="fa fa-user fa-4x text-light"></i>
                  <h3 class="title">EDIT PROFILE</h3>
                  <p>To change your profile image or Reset your password.</p>
                  <a href="<?php echo e(route('trainer.profile')); ?>" class="btn btn-orange">Click here</a>
                </div>
              </div>
              <!-- /col-md-6 -->
              
              <?php if(Auth::user()->status == 0): ?>
              <!--/ col-md-6 -->
              <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 mb">
                <div class="panel-box">
                  <p class="banner">365Homeimprovement</p>
                  <div class="pad">
                    <i class="fa fa-certificate fa-4x text-light"></i>
                    <h3 class="title">TRAINER</h3>
                    <p>To become a Training Provider</p>
                    <a href="<?php echo e(route('trainer.register')); ?>" class="btn btn-orange">Click here</a>
                  </div>
                </div>
              </div>
              <?php else: ?>
              <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 mb">
                <div class="panel-box">
                  <p class="banner">365Homeimprovement</p>
                  <div class="pad">
                    <i class="fa fa-certificate fa-4x text-light"></i>
                    <h3 class="title">TRAINER</h3>
                    <p>Update your profile or Ignore if already done.</p>
                    <a href="<?php echo e(route('trainer.index')); ?>" class="btn btn-orange">Click here</a>
                  </div>
                </div>
              </div>
              <!-- /col-md-6 -->
              <?php endif; ?>
            </div>
            <!-- /row -->
          </div>
          <!-- /col-lg-9 END SECTION MIDDLE -->
          <!-- **********************************************************************************************************************************************************
              RIGHT SIDEBAR CONTENT
              *********************************************************************************************************************************************************** -->
          <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 ds">
            <!-- RECENT ACTIVITIES SECTION -->
            <h4 class="centered mt">RECENT ACTIVITY</h4>
            <!-- First Activity -->
            <div class="desc">
              <div class="thumb">
                <span class="badge bg-info"><i class="fa fa-clock-o"></i></span>
              </div>
              <div class="details">
                <p>
                  <muted>Just Now</muted>
                  <br/>
                  <a href="#">Paul Rudd</a> purchased an item.<br/>
                </p>
              </div>
            </div>
            <!-- Second Activity -->
            <div class="desc">
              <div class="thumb">
                <span class="badge bg-info"><i class="fa fa-clock-o"></i></span>
              </div>
              <div class="details">
                <p>
                  <muted>2 Minutes Ago</muted>
                  <br/>
                  <a href="#">James Brown</a> subscribed to your newsletter.<br/>
                </p>
              </div>
            </div>
            <!-- Third Activity -->
            <div class="desc">
              <div class="thumb">
                <span class="badge bg-info"><i class="fa fa-clock-o"></i></span>
              </div>
              <div class="details">
                <p>
                  <muted>3 Hours Ago</muted>
                  <br/>
                  <a href="#">Diana Kennedy</a> purchased a year subscription.<br/>
                </p>
              </div>
            </div>
            
            <!-- CALENDAR-->
            <div id="calendar">
              <div class="panel green-panel no-margin">
                <div class="panel-body">
                  <div id="date-popover" class="popover top" style="cursor: pointer; disadding: block; margin-left: 33%; margin-top: -50px; width: 175px;">
                    <div class="arrow"></div>
                    <h3 class="popover-title" style="disadding: none;"></h3>
                    <div id="date-popover-content" class="popover-content"></div>
                  </div>
                  <div id="my-calendar"></div>
                </div>
              </div>
            </div>
            <!-- / calendar -->
          </div>
          <!-- /col-lg-3 -->
        </div>
        <!-- /row -->
      </section>
    </section>
    <!--main content end-->

    <!--footer start-->
    <?php echo $__env->make('layouts.backend.footer-copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--footer end-->
  </section>

  <!-- js placed at the end of the document so the pages load faster -->
  <?php echo $__env->make('layouts.backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <script type="text/javascript">
    $(document).ready(function() {
      var unique_id = $.gritter.add({
        // (string | mandatory) the heading of the notification
        title: 'Welcome to 365homeimprovement!',
        // (string | mandatory) the text inside the notification
        text: 'Hover me to enable the Close Button. You can hide the left sidebar clicking on the button next to the logo.',
        // (string | optional) the image to display on the left
        image: '/img/365logo.png',
        // (bool | optional) if you want it to fade out on its own or just sit there
        sticky: false,
        // (int | optional) the time you want it to be alive for before fading out
        time: 5000,
        // (string | optional) the class name you want to apply to that specific message
        class_name: 'my-sticky-class'
      });

      return false;
    });
  </script>

</body>

</html>
<?php /**PATH E:\Laravel - 365home\Homeimprovement\resources\views/user/trainers/dashboard.blade.php ENDPATH**/ ?>