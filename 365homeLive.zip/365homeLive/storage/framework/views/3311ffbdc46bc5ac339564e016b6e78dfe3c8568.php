<aside>
  <div id="sidebar" class="nav-collapse ">
    <!-- sidebar menu start-->
    <ul class="sidebar-menu" id="nav-accordion">
      <p class="centered"><a href="<?php echo e(url('#')); ?>"><img src="<?php echo e(Auth::user()->avatar); ?>" class="avatar"></a></p>
      <h5 class="centered"><?php echo e(Auth::user()->username); ?></h5>
      <li class="sidenav mt">
        <?php if(Auth::user()->role_id == 1): ?>
          <a class="active" href="<?php echo e(route('contractor.dashboard')); ?>">
        <?php elseif(Auth::user()->role_id == 2): ?>
          <a class="active" href="<?php echo e(route('trainer.dashboard')); ?>">
        <?php elseif(Auth::user()->role_id == 3): ?>
          <a class="active" href="<?php echo e(route('marketer.dashboard')); ?>">
        <?php else: ?>
          <a class="active" href="<?php echo e(route('homeowner.dashboard')); ?>">
        <?php endif; ?>
        <i class="fa fa-dashboard"></i> <span>Dashboard</span>
        </a>
      </li>
      <li class="sidenav">
        <?php if(Auth::user()->role_id == 1): ?>
          <a href="<?php echo e(route('contractor.profile')); ?>">
        <?php elseif(Auth::user()->role_id == 2): ?>
          <a href="<?php echo e(route('trainer.profile')); ?>">
        <?php elseif(Auth::user()->role_id == 3): ?>
          <a href="<?php echo e(route('marketer.profile')); ?>">
        <?php else: ?>
          <a href="<?php echo e(route('homeowner.profile')); ?>">
        <?php endif; ?>
        <i class="fa fa-user"></i> <span>Profile</span>
        </a>
      </li>
      <?php if(Auth::user()->role_id == 1): ?>
      <li class="sidenav">
        <a href="<?php echo e(route('contractor.index')); ?>">
          <i class="fa fa-building-o"></i>
          <span>Contractor</span>
        </a>
      </li>
      <?php endif; ?>
      <li class="sidenav sub-menu">
        <a href="javascript:;">
          <i class="fa fa-desktop"></i>
          <span>UI Elements</span>
        </a>
        <ul class="sub">
          <li><a href="<?php echo e(url('#')); ?>">General</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Buttons</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Panels</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Font Awesome</a></li>
        </ul>
      </li>    
    </ul>
    <!-- sidebar menu end-->
  </div>
</aside>




<!--ul.sidebar-menu li a.active--><?php /**PATH C:\Users\DEEONE\Desktop\Homeimprovement-Admin\resources\views/layouts/backend/sidebar.blade.php ENDPATH**/ ?>