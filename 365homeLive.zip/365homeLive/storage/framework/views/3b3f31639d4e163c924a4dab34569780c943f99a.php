 <!--/ Carousel Star /-->
  <div class="intro intro-carousel">
    <div id="carousel" class="owl-carousel owl-theme">
      <div class="carousel-item-a intro-item bg-image" style="background-image: url(img/slide-1.jpg)">
        <div class="overlay overlay-a"></div>
        <div class="intro-content display-table">
          <div class="table-cell">
            <div class="container">
              <div class="row">
                <div class="col-lg-8">
                  <div class="intro-body">
                    <p class="intro-title-top">Lagos
                      <br> 23401</p>
                    <h1 class="intro-title mb-4">
                      <span class="color-b">12 </span> Ogunmodede Street
                      <br> Allen Avenue, Ikeja </h1>
                    <p class="intro-subtitle intro-price">
                      <a href="#"><span class="price-a">rent | 5,000,000.00 NGN</span></a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="carousel-item-a intro-item bg-image" style="background-image: url(img/slide-2.jpg)">
        <div class="overlay overlay-a"></div>
        <div class="intro-content display-table">
          <div class="table-cell">
            <div class="container">
              <div class="row">
                <div class="col-lg-8">
                  <div class="intro-body">
                    <p class="intro-title-top">Port Harcourt
                      <br> 23484</p>
                    <h1 class="intro-title mb-4">
                      <span class="color-b">84 </span> Forces Avenue
                      <br> Orogbum</h1>
                    <p class="intro-subtitle intro-price">
                      <a href="#"><span class="price-a">rent | 2,500,000.00 NGN</span></a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="carousel-item-a intro-item bg-image" style="background-image: url(img/slide-3.jpg)">
        <div class="overlay overlay-a"></div>
        <div class="intro-content display-table">
          <div class="table-cell">
            <div class="container">
              <div class="row">
                <div class="col-lg-8">
                  <div class="intro-body">
                    <p class="intro-title-top">Abuja
                      <br> 23409</p>
                    <h1 class="intro-title mb-4">
                      <span class="color-b">Plot B9 </span> Church Road
                      <br> Karu Site, Karu</h1>
                    <p class="intro-subtitle intro-price">
                      <a href="#"><span class="price-a">rent | 10,000,000.00 NGN</span></a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--/ Carousel end /--><?php /**PATH C:\Users\DEEONE\Desktop\Homeimprovement-Admin\resources\views/layouts/carousel.blade.php ENDPATH**/ ?>