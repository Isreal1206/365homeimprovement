<!DOCTYPE html>
<html lang="en">
<head>
  <?php echo $__env->yieldContent('heading'); ?>
</head>

<body>
	<main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>

<?php echo $__env->yieldContent('footer'); ?>
</html>
<?php /**PATH C:\Users\DEEONE\Desktop\Laravel - 365home\Homeimprovement\resources\views/layouts/app-custom.blade.php ENDPATH**/ ?>