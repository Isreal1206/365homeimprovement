<footer class="site-footer">
  <div class="text-center">
    <p>
      &copy; 2019 <strong>Hausworth Nigeria Limited.</strong>
    </p>
    <a href="<?php echo e(url('#')); ?>" class="go-top">
      <i class="fa fa-angle-up"></i>
    </a>
  </div>
</footer><?php /**PATH C:\Users\DEEONE\Desktop\Laravel - 365home Ipage\Homeimprovement\resources\views/layouts/backend/footer-copyright.blade.php ENDPATH**/ ?>