<?php $__env->startSection('heading'); ?>
  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section class="section-t8 pb-5">
    <div class="container">
      <div class="row my-3">
        <div class="col-sm-12 col-md-12 col-lg-12">
          <h1 class="text-center">Let's make your House a <strong class="text-orange"><i class="fa fa-home"></i>ome</strong></h1>
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12">
          <h3 class="text-center mb-5"><em>Fast, Easy and Free to <span class="text-orange">get quotes</span> from the right <span class="text-orange">contractors!</span></em></h3>
        </div>
      </div>

      <form name="form-quote" action="<?php echo e(route('request')); ?>">
      <div class="row offset-md-1">
        <div class="col-12 col-sm-12 col-md-3 col-lg-3 mb-3">
          <label for="category">Select Category:</label>
          <select id="category" onchange="getSelectValue();" name="category" class="form-control<?php echo e($errors->has('category') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('category')); ?>" required>
            <option selected="selected"></option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="col-12 col-sm-12 col-md-3 col-lg-3 mb-3">
          <label for="state">Select State:</label>
          <select class="form-control" name="state" id="state" onclick="populate('state','lga')" required>
            <option selected="selected"></option>
            <option value='Abia'>Abia</option>
            <option value='Adamawa'>Adamawa</option>
            <option value='AkwaIbom'>Akwa Ibom</option>
            <option value='Anambra'>Anambra</option>
            <option value='Bauchi'>Bauchi</option>
            <option value='Bayelsa'>Bayelsa</option>
            <option value='Benue'>Benue</option>
            <option value='Borno'>Borno</option>
            <option value='Cross Rivers'>Cross Rivers</option>
            <option value='Delta'>Delta</option>
            <option value='Ebonyi'>Ebonyi</option>
            <option value='Edo'>Edo</option>
            <option value='Ekiti'>Ekiti</option>
            <option value='Enugu'>Enugu</option>
            <option value='Gombe'>Gombe</option>
            <option value='Imo'>Imo</option>
            <option value='Jigawa'>Jigawa</option>
            <option value='Kaduna'>Kaduna</option>
            <option value='Kano'>Kano</option>
            <option value='Katsina'>Katsina</option>
            <option value='Kebbi'>Kebbi</option>
            <option value='Kogi'>Kogi</option>
            <option value='Kwara'>Kwara</option>
            <option value='Lagos'>Lagos</option>
            <option value='Nasarawa'>Nasarawa</option>
            <option value='Niger'>Niger</option>
            <option value='Ogun'>Ogun</option>
            <option value='Ondo'>Ondo</option>
            <option value='Osun'>Osun</option>
            <option value='Oyo'>Oyo</option>
            <option value='Plateau'>Plateau</option>
            <option value='Rivers'>Rivers</option>
            <option value='Sokoto'>Sokoto</option>
            <option value='Taraba'>Taraba</option>
            <option value='Yobe'>Yobe</option>
            <option value='Zamfara'>Zamafara</option>
          </select>
        </div>

        <div class="col-12 col-sm-12 col-md-3 col-lg-3 mb-3">
          <label for="lga">Select LGA:</label>
          <select class="form-control" name="lga" id="lga" required>
            <option selected="selected"></option>
          </select>
        </div>

        <div class="col-12 col-sm-12 col-md-2 col-lg-2 mb-3 d-flex">
          <input type="submit" name="submit" class="btn btn-orange align-self-end" value="Request Quote" onclick="run();">
        </div>

      </div>
    </form>

    <div class="row">
      <div class="col-12 col-sm-12 col-md-12 col-lg-12">
        <marquee><strong>Our Partners and Sister Company:</strong>
          365 Property Portal --- <a href="#" class="text-primary">www.365propertyportal.com</a> (Nigeria’s One Stop Property Portal)</marquee>
      </div>
    </div>

    </div>
  </section>

  <section class="section-border">
    <div class="container-fluid hiw mt-5" style="background-image:url(<?php echo e(url('img/bgstarted.jpg')); ?>)">
      <div class="transparent py-2">
        <div class="row m-4">
          <div class="title-box col-sm-12 col-md-12 col-lg-12">
            <h4 class="title-list text-center">HOW IT WORKS</h4>
          </div>
        </div>
        <div class="row my-0">
          <div class="col-sm-3 col-md-3 col-lg-3">
            <div class="py-2">
              <div class="mb-4">
                <img class="img-fluid d-block mx-auto" src="<?php echo e(URL::to('/')); ?>/img/sign-up.png" alt=""/>
              </div>
              <div>
                <h4 class="contractor-head text-white mb-2">1. Sign Up</h4>
                <p class="text-center text-white text-shadow">Register as a premium member <br>and start receiving leads</p>
              </div>
            </div>
          </div>
          <div class="col-sm-3 col-md-3 col-lg-3">
            <div class="py-2">
              <div class="mb-4">
                <img class="img-fluid d-block mx-auto" src="<?php echo e(URL::to('/')); ?>/img/eoi.png" alt=""/>
              </div>
              <div>
                <h4 class="contractor-head text-white mb-2">2. Expression of Interest</h4>
                <p class="text-center text-white text-shadow">Pick and choose from leads in<br> your area</p>
              </div>
            </div>
          </div>
          <div class="col-sm-3 col-md-3 col-lg-3">
            <div class="py-2">
              <div class="mb-4">
                <img class="img-fluid d-block mx-auto" src="<?php echo e(URL::to('/')); ?>/img/get-shortlisted.png" alt=""/>
              </div>
              <div>
                <h4 class="contractor-head text-white mb-2">3. Get Shortlisted</h4>
                <p class="text-center text-white text-shadow">Contact details are exchanged</p>
              </div>
            </div>
          </div>
          <div class="col-sm-3 col-md-3 col-lg-3">
            <div class="py-2">
              <div class="mb-4">
                <img class="img-fluid d-block mx-auto" src="<?php echo e(URL::to('/')); ?>/img/earn-feedback.png" alt=""/>
              </div>
              <div>
                <h4 class="contractor-head text-white mb-2">4. Earn Feedback</h4>
                <p class="text-center text-white text-shadow">Win work and build your portfolio</p>
              </div>
            </div>
          </div>
        </div>
        <div class="row m-3 d-flex justify-content-center">
          <a href="<?php echo e(route('register')); ?>" class="btn btn-orange">Get Started<i class="ml-2 ion-ios-arrow-forward"></i></a>
        </div>
      </div>

    </div>
  </section>
<!--/ Contractor Ends /-->

<!--/ Market Starts /-->
  <section class="section-border section-t8 nav-arrow-a">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a">Market Place</h2>
            </div>
          </div>
        </div>
      </div>
      <div id="market-carousel" class="owl-carousel owl-arrow">
        <div class="carousel-item-a">
          <h4 class="z-title-a">Kitchen & Dinning</h4>
          <div class="testimonials-box">
            <div class="row d-flex justify-content-center">
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/kitchen/cabinet-and-drawer-hardware.png" alt=""/></i>
                  <span>Cabinet & Drawer Hardware</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/kitchen/cookware-and-bakeware.png" alt=""/></i>
                  <span>Cookware & Bakeware</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/kitchen/kitchen-and-cabinet-lighting.png" alt=""/></i>
                  <span>Kitchen & Cabinet Lighting</span>
                </a>
              </div>    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/kitchen/kitchen-and-dinning-furniture.png" alt=""/></i>
                  <span>Kitchen & Dining Furniture</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/kitchen/kitchen-appliances.png" alt=""/></i>
                  <span>Kitchen Appliances</span>
                </a>
              </div>
            </div>
            <div class="row d-flex justify-content-center">
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/kitchen/kitchen-fixtures.png" alt=""/></i>
                  <span>Kitchen Fixtures</span>
                </a>
              </div>    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/kitchen/kitchen-storage-and-organization.png" alt=""/></i>
                  <span>Kitchen Storage & Organization</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/kitchen/kitchen-tools-and-gadgets.png" alt=""/></i>
                  <span>Kitchen Tools & Gadgets</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/kitchen/table-top.png" alt=""/></i>
                  <span>Tabletop</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/kitchen/tiles.png" alt=""/></i>
                  <span>Tile</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item-a">
          <h4 class="z-title-a">Bath Products</h4>
          <div class="testimonials-box">
            <div class="row d-flex justify-content-center">
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bath/bathroom-accessories.png" alt=""/></i>
                  <span>Bathroom Accessories</span>
                </a>
              </div>  
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bath/bathroom-faucets.png" alt=""/></i>
                  <span>Bathroom Faucets</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bath/bathroom-linens.png" alt=""/></i>
                  <span>Bath Linens</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bath/bathroom-sinks.png" alt=""/></i>
                  <span>Bathroom Sinks</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bath/bathroom-vanities.png" alt=""/></i>
                  <span>Bathroom Vanities</span>
                </a>
              </div>
            </div>
            <div class="row d-flex justify-content-center">    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bath/bathroom-vanity-lighting.png" alt=""/></i>
                  <span>Bathroom Vanity Lighting</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bath/bathtubs.png" alt=""/></i>
                  <span>Bathtubs</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bath/medicine-cabinets.png" alt=""/></i>
                  <span>Medicine Cabinets</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bath/showers.png" alt=""/></i>
                  <span>Showers</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bath/tiles.png" alt=""/></i>
                  <span>Tile</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item-a">
          <h4 class="z-title-a">Bedroom Products</h4>
          <div class="testimonials-box">
            <div class="row d-flex justify-content-center">    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bedroom/bedding.png" alt=""/></i>
                  <span>Bedding</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bedroom/bedroom-benches.png" alt=""/></i>
                  <span>Bedroom Benches</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bedroom/bedroom-decor.png" alt=""/></i>
                  <span>Bedroom Decor</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bedroom/beds-&-headboards.png" alt=""/></i>
                  <span>Beds & Headboards</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bedroom/chaise-longue-chairs.png" alt=""/></i>
                  <span>Chaise Lounge Chairs</span>
                </a>
              </div>
            </div>
            <div class="row d-flex justify-content-center">
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bedroom/closet-storage.png" alt=""/></i>
                  <span>Closet Storage</span>
                </a>
              </div>  
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bedroom/dressers.png" alt=""/></i>
                  <span>Dressers</span>
                </a>
              </div>  
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bedroom/futons.png" alt=""/></i>
                  <span>Futons</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bedroom/lamps.png" alt=""/></i>
                  <span>Lamps</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/bedroom/nightstand-&-bedside-tables.png" alt=""/></i>
                  <span>Nightstands & Bedside Tables</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item-a">
          <h4 class="z-title-a">Living Products</h4>
          <div class="testimonials-box">
            <div class="row d-flex justify-content-center">
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/living/armchairs-&-accent-chairs.png" alt=""/></i>
                  <span>Armchairs & Accent Chairs</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/living/artwork.png" alt=""/></i>
                  <span>Artwork</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/living/bookcases.png" alt=""/></i>
                  <span>Bookcases</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/living/coffee-&-accent-table.png" alt=""/></i>
                  <span>Coffee & Accent Tables</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/living/fireplaces-&-accessories.png" alt=""/></i>
                  <span>Fireplaces & Accessories</span>
                </a>
              </div>
            </div>
            <div class="row d-flex justify-content-center">
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/living/home-decor.png" alt=""/></i>
                  <span>Home Decor</span>
                </a>
              </div>    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/living/lamps.png" alt=""/></i>
                  <span>Lamps</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/living/media-storage.png" alt=""/></i>
                  <span>Media Storage</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/living/rugs.png" alt=""/></i>
                  <span>Rugs</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/living/sofas-&-sectionals.png" alt=""/></i>
                  <span>Sofas & Sectionals</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item-a">
          <h4 class="z-title-a">Lighting</h4>
          <div class="testimonials-box">
            <div class="row d-flex justify-content-center">
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/lighting/bathroom-vanity-lighting.png" alt=""/></i>
                  <span>Bathroom Vanity Lighting</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/lighting/ceiling-fans.png" alt=""/></i>
                  <span>Ceiling Fans</span>
                </a>
              </div>    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/lighting/chandelier.png" alt=""/></i>
                  <span>Chandeliers</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/lighting/floor-lamps.png" alt=""/></i>
                  <span>Floor Lamps</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/lighting/flush-mount-ceiling-lighting.png" alt=""/></i>
                  <span>Flush-Mount Ceiling Lighting</span>
                </a>
              </div>
            </div>
            <div class="row d-flex justify-content-center">    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/lighting/kitchen-&-cabinets-lighting.png" alt=""/></i>
                  <span>Kitchen & Cabinet Lighting</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/lighting/outdoor-lighting.png" alt=""/></i>
                  <span>Outdoor Lighting</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/lighting/pendant-lighting.png" alt=""/></i>
                  <span>Pendant Lighting</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/lighting/table-lamps.png" alt=""/></i>
                  <span>Table Lamps</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/lighting/wall-sconces.png" alt=""/></i>
                  <span>Wall Sconces</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item-a">
          <h4 class="z-title-a">Furniture</h4>
          <div class="testimonials-box">
            <div class="row d-flex justify-content-center">
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/furniture/bathroom-storage-&-vanities.png" alt=""/></i>
                  <span>Bathroom Storage & Vanities</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/furniture/bedroom-furniture.png" alt=""/></i>
                  <span>Bedroom Furniture</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/furniture/home-office-furniture.png" alt=""/></i>
                  <span>Home Office Furniture</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/furniture/kitchen-&-dining-furniture.png" alt=""/></i>
                  <span>Kitchen & Dining Furniture</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/furniture/livingroom-furniture.png" alt=""/></i>
                  <span>Living Room Furniture</span>
                </a>
              </div>
            </div>
            <div class="row d-flex justify-content-center">    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/furniture/outdoor-furniture.png" alt=""/></i>
                  <span>Outdoor Furniture</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/furniture/storage-furniture.png" alt=""/></i>
                  <span>Storage Furniture</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item-a">
          <h4 class="z-title-a">Home Decor</h4>
          <div class="testimonials-box">
            <div class="row d-flex justify-content-center">
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/home-decor/artwork.png" alt=""/></i>
                  <span>Artwork</span>
                </a>
              </div>    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/home-decor/decorative-accents.png" alt=""/></i>
                  <span>Decorative Accents</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/home-decor/mirrors.png" alt=""/></i>
                  <span>Mirrors</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/home-decor/pillows-&-throws.png" alt=""/></i>
                  <span>Pillows & Throws</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/home-decor/rugs.png" alt=""/></i>
                  <span>Rugs</span>
                </a>
              </div>
            </div>
            <div class="row d-flex justify-content-center">    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/home-decor/wall-decor.png" alt=""/></i>
                  <span>Wall Decor</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/home-decor/window-treatments.png" alt=""/></i>
                  <span>Window Treatments</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item-a">
          <h4 class="z-title-a">Home Improvement</h4>
          <div class="testimonials-box">
            <div class="row d-flex justify-content-center">    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/home/bathroom-fixtures.png" alt=""/></i>
                  <span>Bathroom Fixtures</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/home/building-materials.png" alt=""/></i>
                  <span>Building Materials</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/home/hardware.png" alt=""/></i>
                  <span>Hardware</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/home/heating-&-cooling.png" alt=""/></i>
                  <span>Heating & Cooling</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/home/kitchen-fixtures.png" alt=""/></i>
                  <span>Kitchen Fixtures</span>
                </a>
              </div>              
            </div>
            <div class="row d-flex justify-content-center">    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/home/tiles.png" alt=""/></i>
                  <span>Tile</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/home/tools-&-equipments.png" alt=""/></i>
                  <span>Tools & Equipment</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item-a">
          <h4 class="z-title-a">Outdoor Products</h4>
          <div class="testimonials-box">
            <div class="row d-flex justify-content-center">
            <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/outdoor/lawn-&-garden.png" alt=""/></i>
                  <span>Lawn & Garden</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/outdoor/outdoor-cooking.png" alt=""/></i>
                  <span>Outdoor Cooking</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/outdoor/outdoor-decor.png" alt=""/></i>
                  <span>Outdoor Decor</span>
                </a>
              </div>    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/outdoor/outdoor-furniture.png" alt=""/></i>
                  <span>Outdoor Furniture</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/outdoor/outdoor-lighting.png" alt=""/></i>
                  <span>Outdoor Lighting</span>
                </a>
              </div>
            </div>
            <div class="row d-flex justify-content-center">    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/outdoor/outdoor-structures.png" alt=""/></i>
                  <span>Outdoor Structures</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/outdoor/pool-&-spa.png" alt=""/></i>
                  <span>Pool & Spa</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item-a">
          <h4 class="z-title-a">Storage & Organization</h4>
          <div class="testimonials-box">
            <div class="row d-flex justify-content-center">    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/storage/media-storage.png" alt=""/></i>
                  <span>Media Storage</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/storage/office-storage.png" alt=""/></i>
                  <span>Office Storage</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/storage/storage-furniture.png" alt=""/></i>
                  <span>Storage Furniture</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item-a">
          <h4 class="z-title-a">Housekeeping & Laundry</h4>
          <div class="testimonials-box">
            <div class="row d-flex justify-content-center">    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/housekeeping/ironing-boards.png" alt=""/></i>
                  <span>Ironing Boards</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/housekeeping/irons.png" alt=""/></i>
                  <span>Irons</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/housekeeping/laundry-hangers.png" alt=""/></i>
                  <span>Laundry Hangers</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item-a">
          <h4 class="z-title-a">Holiday Decor</h4>
          <div class="testimonials-box">
            <div class="row d-flex justify-content-center">    
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/holiday/holiday-accents-&-figurines.png" alt=""/></i>
                  <span>Holiday Accents & Figurines</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/holiday/holiday-lighting.png" alt=""/></i>
                  <span>Holiday Lighting</span>
                </a>
              </div>
              <div class="product-items">
                <a href="#">
                  <i><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/img/icons/holiday/wreaths-&-garlands.png" alt=""/></i>
                  <span>Wreaths & Garlands</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<!--/ Market Ends /-->

<!--/ Training Starts /-->
  <section class="border-line section-t8 mb-5">
    <div class="container">
      <div class="row">
        <div class="col-md-12 title-wrap d-flex justify-content-between">
          <div class="title-box">
            <h2 class="title-a">Training</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-8 mb-4">
          <img class="img-fluid" src="<?php echo e(URL::to('/')); ?>/img/training.png" alt=""/>
          <!--<img src="img/test.jpg" alt="" class="img-fluid">-->
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4 text-justify">
          <div class="mb-3">
            <h3 class="training-title mb-3">Training Programs</h3>
            <p class="text-training">365 Home Improvement is the one stop solution for human resource development in the home improvement industry in Nigeria. Click the button below to get started.
            </p>
          </div>
          <div class="d-flex justify-content-center">
            <a href="<?php echo e(route('training')); ?>" class="btn btn-orange">Get Started<i class="ml-2 ion-ios-arrow-forward"></i></a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <?php echo $__env->make('layouts.footer-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.app-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DEEONE\Desktop\Homeimprovement-Admin\resources\views/index.blade.php ENDPATH**/ ?>