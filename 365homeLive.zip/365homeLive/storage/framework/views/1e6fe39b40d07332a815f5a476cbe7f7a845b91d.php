<!-- /Footer Blog Starts/ -->
<footer>
<div class="copyright-footer">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-orange text-left">
        &copy; 2019
        <span class="text-orange"><strong>Hausworth Nigeria Limited.</strong></span> 
      </div>
      <!--<div class="col-md-6 text-right">
      Designed by <a href="<?php echo e(url('https://ultramediasolution.com')); ?>" class="color-a"><strong>Ultra Media Solution Team</strong></a>
      </div> -->
    </div>
  </div>
</div>
<a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
<div id="preloader"></div>
</footer>
<!-- /Footer Ends/ -->

<!--
  <div class="credits">
      All the links in the footer should remain intact.
      You can delete the links only if you purchased the pro version.
      Licensing information: https://bootstrapmade.com/license/
      Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=EstateAgenc</div>
  </div> 
--><?php /**PATH E:\Laravel - 365home\365homeimprovement\resources\views/layouts/footer-copyright.blade.php ENDPATH**/ ?>