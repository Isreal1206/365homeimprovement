<!DOCTYPE html>
<html lang="en">

<head>
  <!--header start-->
  <?php echo $__env->make('layouts.backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!--header end-->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--navbar start-->
    <?php echo $__env->make('layouts.backend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--navbar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <?php echo $__env->make('layouts.backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="row content-panel">
             
              <!-- /panel-heading -->
              <div class="panel-body">
                <div class="tab-content">
                  <!-- /tab-pane -->
                  <div id="edit" class="tab-pane active">
                    <div class="row site-min-height">
                      <div class="col-lg-8 col-lg-offset-2 detailed">
                        <h4 class="mb">All Properties</h4>
                        <?php if($flash = session('success')): ?>
                          <div class="alert alert-success" role="alert">
                            <?php echo e($flash); ?>

                          </div>
                        <?php endif; ?>
                        <div class="panel-heading">
                        <div class="row mb-100">
                        <?php $__currentLoopData = $requestQuote; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 height-50">
                          <a data-toggle="tab" href="#<?php echo e($request->id); ?>">
                          <div class="padx-1 pady-1 border-custom">
                            <img src="<?php echo e($request->image_file); ?>" class="img-responsive w-100 height-150">
                          </div>
                          </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        </div>

                        <div class="row">
                          <h4 class="mt-100">Display Property Information</h4>
                          <?php $__currentLoopData = $requestQuote; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="panel-body">
                          <div class="tab-content">
                          <div id="<?php echo e($request->id); ?>" class="tab-pane">
                            <div class="col-lg-5 height-350">
                              <div class="padx-2 pady-2 border-custom">
                                <img src="<?php echo e($request->image_file); ?>" class="img-responsive w-100 height-300">
                                <p class="text-center text-capitalize mt-15"><?php echo e($request->created_at->format ('M, d Y.')); ?></p>
                              </div>
                            </div>

                            <div class="col-lg-6 col-lg-offset-1">
                              <p class="text-capitalize"><strong>Category:</strong> <?php echo e($request->category); ?></p>
                              <p class="text-capitalize"><strong>State:</strong> <?php echo e($request->state); ?></p>
                              <p class="text-capitalize"><strong>LGA:</strong> <?php echo e($request->lga); ?></p>
                              <p class="text-capitalize"><strong>Start Date:</strong> <?php echo e($request->start_work); ?></p>
                              <p class="text-capitalize"><strong>Type of Property:</strong> <?php echo e($request->property_type); ?></p>
                              <p class="text-capitalize"><strong>Type of Work:</strong> <?php echo e($request->work_type); ?></p>
                              <p class="text-capitalize"><strong>Budget:</strong> <?php echo e($request->budget); ?></p>
                              <p class="text-capitalize"><strong>Job Status:</strong> <?php echo e($request->job_status); ?></p>
                              <p class="text-capitalize"><strong>Property Relationship:</strong> <?php echo e($request->property_relation); ?></p>
                              <p class="text-capitalize"><strong>No. of Bids:</strong> <?php echo e($request->bid_no); ?></p>
                              <p class="text-capitalize"><strong>Best Time of Contact:</strong> <?php echo e($request->contact_time); ?></p>
                              <p class="text-capitalize text-justify"><strong>Description:</strong> <?php echo e($request->description); ?></p>
                            </div>
                          </div>
                          </div>
                          </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                      </div>
                      <!-- /col-lg-8 -->
                    </div>
                    <!-- /row -->
                  </div>
                  <!-- /tab-pane -->
                </div>
                <!-- /tab-content -->
              </div>
              <!-- /panel-body -->
            </div>
            <!-- /col-lg-12 -->
          </div>
          <!-- /row -->
        </div>
        <!-- /container -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    
    <!--footer start-->
    <?php echo $__env->make('layouts.backend.footer-copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--footer end-->
  </section>

  <!-- js placed at the end of the document so the pages load faster -->
  <?php echo $__env->make('layouts.backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script>
    function myFunction() {
      document.getElementById("demo").innerHTML = "Hello World";
    }
    
    document.getElementById("myBtn").addEventListener("click", displayDate);

    function displayDate() {
      document.getElementById("demo").innerHTML = Date();
    }
  </script>

</body>

</html>
<?php /**PATH C:\Users\DEEONE\Desktop\Laravel - 365home Ipage\365homeimprovement\resources\views/user/home_owners/properties.blade.php ENDPATH**/ ?>