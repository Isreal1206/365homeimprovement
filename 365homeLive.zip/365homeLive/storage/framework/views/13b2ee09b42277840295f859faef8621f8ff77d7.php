<!DOCTYPE html>
<html lang="en">

<head>
  <!--header start-->
  <?php echo $__env->make('layouts.backend.admin-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!--header end-->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--navbar start-->
    <?php echo $__env->make('layouts.backend.admin-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--navbar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <?php echo $__env->make('layouts.backend.admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="row content-panel">
              <div class="panel-heading">
                <ul class="nav nav-tabs nav-justified">
                  <li  class="active">
                    <a data-toggle="tab" href="#contractors" class="contact-map">All Contractors</a>
                  </li>
                  <li>
                    <a data-toggle="tab" href="#edit">Edit Contractor</a>
                  </li>
                  <li>
                    <a data-toggle="tab" href="#overview">Overview</a>
                  </li>
                </ul>
              </div>
              <!-- /panel-heading -->
              <div class="panel-body">
                <div class="tab-content">
                  <div id="contractors" class="tab-pane active">
                    <div class="row site-min-height">
                      <div class="col-md-10 col-md-offset-1 detailed">
                        <h4>List of 365Homeimprovement Contractors</h4>
                        <div class="mt">
                          <h3 class="text-danger">List not found.</h3>
                        </div>
                        
                      </div>
                      <!-- /col-md-6 -->
                    </div>
                    <!-- /row -->
                  </div>
                  <!-- /tab-pane -->

                  <div id="edit" class="tab-pane">
                    <div class="row site-min-height">
                      <div class="col-md-10 col-md-offset-1 detailed mt">
                        <?php if($flash = session('success')): ?>
                          <div class="alert alert-success" role="alert">
                            <?php echo e($flash); ?>

                          </div>
                        <?php endif; ?>
                        <form method="POST" action="" role="form" class="form-horizontal">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                          <label class="col-lg-3 control-label">Company Logo:</label>
                          <div class="col-lg-7">
                            <input type="file" id="company_logo" class="file-pos" name="logo">
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label">Company Name:</label>
                          <div class="col-lg-7">
                            <input type="text" placeholder="" id="company_name" class="form-control" name="company_name">
                            <small class="text-danger"><?php echo e($errors->first('company_name')); ?></small>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label">Job Category:</label>
                          <div class="col-lg-7">
                            <select name="category_id" class="form-control">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label">Phone Number:</label>
                          <div class="col-lg-7">
                            <input type="text" placeholder="" id="phone" class="form-control" name="phone">
                            <small class="text-danger"><?php echo e($errors->first('phone')); ?></small>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label">Company Address:</label>
                          <div class="col-lg-7">
                            <input type="text" placeholder="" id="address" class="form-control" name="address">
                            <small class="text-danger"><?php echo e($errors->first('address')); ?></small>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label">Description:</label>
                          <div class="col-lg-7">
                            <textarea rows="7" cols="20" class="form-control" id="description" name="description"></textarea>
                            <small class="text-danger"><?php echo e($errors->first('description')); ?></small>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-lg-offset-3 col-lg-7">
                            <button class="btn btn-theme" type="submit">Save</button>
                            <button class="btn btn-theme04" type="button">Cancel</button>
                          </div>
                        </div>
                        </form>
                      </div>
                      <!-- /col-lg-8 -->
                    </div>
                    <!-- /row -->
                  </div>
                  <!-- /tab-pane -->

                  <div id="overview" class="tab-pane">
                    <div class="row site-min-height">

                      <div class="col-md-10 col-md-offset-1 detailed">
                        <div class="col-md-3 pull-right mt">
                          <img src="" alt="Company Logo" class="custom-circle">
                        </div>
                        <!-- detailed -->
                        <div class="col-md-12 table-responsive mt">

                          <table class="table table-striped">
                          <tr>
                            <th>COMPANY NAME:</th>
                            <td><?php echo e(Auth::user()->company); ?></td>
                          </tr>
                          
                          <tr>
                            <th>JOB CATEGORY:</th>
                            <td><?php echo e(Auth::user()->category); ?></td>
                          </tr>

                          <tr>
                            <th>PHONE NUMBER:</th>
                            <td><?php echo e(Auth::user()->phone); ?></td>
                          </tr>

                          <tr>
                            <th>COMPANY ADDRESS:</th>
                            <td><?php echo e(Auth::user()->address); ?></td>
                          </tr>

                          <tr>
                            <th>DESCRIPTION:</th>
                            <td><?php echo e(Auth::user()->description); ?></td>
                          </tr>
                          </table>
                          <!-- /recent-activity -->
                        </div>
                        <!-- /detailed -->

                      </div>

                      <!-- /col-md-12 -->

                    </div>
                    <!-- /OVERVIEW -->
                  </div>
                  <!-- /tab-pane -->

                </div>
                <!-- /tab-content -->
              </div>
              <!-- /panel-body -->
            </div>
            <!-- /col-lg-12 -->
          </div>
          <!-- /row -->
        </div>
        <!-- /container -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->

    <!--footer start-->
    <?php echo $__env->make('layouts.backend.footer-copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--footer end-->
  </section>

  <!-- js placed at the end of the document so the pages load faster -->
  <?php echo $__env->make('layouts.backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\DEEONE\Desktop\Laravel - 365home Ipage\365homeimprovement\resources\views/admin/contractor.blade.php ENDPATH**/ ?>