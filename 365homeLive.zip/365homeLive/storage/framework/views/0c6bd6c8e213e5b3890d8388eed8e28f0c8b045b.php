<?php $__env->startSection('heading'); ?>
  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section>
    <div class="container-fluid p-0">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <div class="banner-head mb-0">
            <img class="img-responsive img-fluid banner-bg" src="<?php echo e(URL::to('/')); ?>/img/page-banner.jpg" alt="Page Banner"/>
            <div class="banner-overlay2">
              <h1 class="text-white text-center" style="font-size: 1.4rem; font-weight: 600; margin-top: 6rem">BECOME A <span class="text-orange">TRAINER</span></h1>
              <p class="text-center text-white">@</p>
              <p class="text-center text-primary">Hausworth Nigeria Limited</p>
              <p class="text-center text-uppercase">
                <a href="<?php echo e(url('trainersLogin')); ?>" class="btn btn-sm btn-primary font-w-6">Login</a>
                <a href="<?php echo e(url('trainersform')); ?>" class="btn btn-sm btn-orange font-w-6">Register</a>
              </p>
            </div>
          </div>
        </div>
      </div>
  	</div>

    <div class="container bg-white pb-5">
      <div class="row p-2">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <p class="text-jusify">Hausworth Nigeria Limited owners of 365 home improvements seeks human resource development firms in different areas of home improvement with a view towards working with them in the provision of quality training services to our users.</p>
        </div>
        <div class="col-sm">
          <img src="<?php echo e(('img/training-banner1.jpg')); ?>" class="d-block mx-auto img-responsive img-fluid py-2">
          <h6 class="text-center text-bold">MORE EARNINGS</h6>
          <p class="text-justify">Training company and trainer’s earns seventy percent (70%) of the cost price of the subscription on our platform. We take care of all the marketing and earn thirty percent (30%).</p>
        </div>
        <div class="col-sm">
          <img src="<?php echo e(('img/training-banner2.jpg')); ?>" class="d-block mx-auto img-responsive img-fluid py-2">
          <h6 class="text-center text-bold">GREATER MARKETING AND PUBLICITY</h6>
          <p class="text-justify">Hausworth Nigeria Limited would ensure maximum marketing and publicity of your trainings on different platforms both online and offline.
          Because we work with other training providers specializing in the different areas of interest, we would be able to attract different subscribers with possible interest in your contents.</p>
        </div>
        <div class="col-sm">
          <img src="<?php echo e(('img/training-banner3.jpg')); ?>" class="d-block mx-auto img-responsive img-fluid py-2">
          <h6 class="text-center text-bold">PAYMENT</h6>
          <p class="text-justify roboto">The amount earned can be easily seen along with your payment and earning history (transaction history).
          The payment would be remitted upon completion of the training. Payment would be made into your account directly.
          In order to become a training provider on our platform, please do provide us with the following details</p>
        </div>
      </div>

      <div class="row p-3">
        <button type="button" class="text-uppercase btn btn-orange font-w-6 mx-auto"><a href="<?php echo e(url('/training/become-a-trainer')); ?>">Become A Training Provider</a></button>
      </div>

      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 mt-5">
          <h4 class="bg-dark text-white text-center mb-4" style="font-family: sans-serif; font-weight: 600; font-size: 1.5rem">TRAINERS GALLERY</h4>
        </div>
      </div>
      
      <div class="row">
        <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 col-sm-12 col-md-12 col-lg-4">
          <div class="position-relative text-center mb-2">
            <img class="img-responsive img-fluid" src="<?php echo e(URL::to('/')); ?>/img/page-banner.jpg" alt="Page Banner" style="height: 30vh" />
            <div class="banner-overlay2 py-5">
              <h4 class="text-footer text-uppercase"><?php echo e($trainer->organization); ?></h4>
              <h6 class="text-white"><i class="fa fa-map-marker mr-1"></i><?php echo e($trainer->address); ?>, <?php echo e($trainer->city); ?>.</h6>
              <h6 class="text-white"><i class="fa fa-envelope mr-1"></i><?php echo e($trainer->email); ?></h6>
              <a href="training/trainer/<?php echo e($trainer->id); ?>" class="btn btn-primary btn-sm text-blink">Click here<i class="fa fa-angle-double-right ml-1"></i></a>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      
    </div>
  </section>

  <?php echo $__env->make('layouts.footer-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DEEONE\Desktop\Homeimprovement-User&Admin\resources\views/links/training/index.blade.php ENDPATH**/ ?>