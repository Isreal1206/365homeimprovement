<?php $__env->startSection('heading'); ?>
  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section>
    <div class="container-fluid p-0">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <div class="banner-head">
            <img class="img-responsive img-fluid banner-bg" src="<?php echo e(URL::to('/')); ?>/img/page-banner.jpg" alt="Page Banner"/>
            <div class="banner-overlay pb-0">
            <h1 class="text-white text-center" style="font-size: 1.4rem; font-weight: 700"><span class="text-orange">BLOG </span>POSTS</h1>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container mb-5">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <div class="alert alert-dark mt-3 mb-5">
            <span class="mr-2"><a href="<?php echo e(url('/')); ?>">Home</a></span>
            <i class="fa fa-angle-double-right"></i>
            <span class="mx-2"><a href="<?php echo e(url('#')); ?>">Blog</a></span>
          </div>
        </div>
      </div> 

      <?php if(count($posts)>0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row py-3 bg-light my-2 mx-0">
          <div class="col-12 col-sm-12 col-md-2 col-lg-2 mb-2">
            <img src="<?php echo e('img/img_blog/' . $post->image_file); ?>" class="img-responsive post-front-img" alt="IMAGE" />
          </div>

          <div class="col-12 col-sm-12 col-md-9 col-lg-9">
            <p class="text-uppercase text-bold" style="font-size: .85rem"><?php echo e($post->title); ?></p>
            <p class="p-0" style="font-size: .9rem">Posted by <strong><?php echo e($post->user->firstname); ?> <?php echo e($post->user->lastname); ?> </strong> </p>
            <p class="p-0" style="font-size: .9rem"><?php echo e(date('j M Y, h:iA', strtotime($post->created_at))); ?></p>
          </div>

          <div class="col-12 col-sm-12 col-md-1 col-lg-1 button-container">
            <!-- <small class="flex-fill align-self-center">Posted by <strong><?php echo e($post->user->name); ?></strong> on <?php echo e($post->created_at -> format ('D: d M Y, H:ia')); ?></small> -->
            <a href="/blog-posts/<?php echo e($post->id); ?>"><button class="btn btn-sm btn-success button-align">Read More</button></a>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($posts->links()); ?>


      <?php else: ?>
        <p>No posts found.</p>
      <?php endif; ?>
  	</div>
  </section>

  <?php echo $__env->make('layouts.footer-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DEEONE\Desktop\Homeimprovement\resources\views/links/blog.blade.php ENDPATH**/ ?>