<nav class="navbar navbar-default navbar-trans navbar-expand-sm fixed-top">
  <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="/img/homelogo.png" class="homelogo"></a>
  <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarDefault"
    aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
    <span></span>
    <span></span>
    <span></span>
  </button>

  

  <div class="collapse navbar-collapse justify-content-center" id="navbarDefault">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/')); ?>"><i class="fa fa-home" aria-hidden="true"></i>Home</a>
      </li>
      
      <li class="nav-item dropdown mega-dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Categories</a>
        <div class="dropdown-menu mega-dropdown-menu bg-menu-position">
          <div class="row px-5">
            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>A</h4>
              <a href="<?php echo e(url('categories/antenna-services')); ?>" class="nav-text">Antenna Services</a>
              <a href="<?php echo e(url('categories/asbestos-removal')); ?>" class="nav-text">Asbestos Removal</a>
              <a href="<?php echo e(url('categories/appliance-installation')); ?>" class="nav-text">Appliance Installation</a>
              <a href="<?php echo e(url('categories/awning-suppliers')); ?>" class="nav-text">Awning Suppliers</a>
              <a href="<?php echo e(url('categories/appliance-repairs')); ?>" class="nav-text">Appliance Repairs</a>
              <a href="<?php echo e(url('categories/awnings')); ?>" class="nav-text">Awnings</a>
              <a href="<?php echo e(url('categories/architecture')); ?>" class="nav-text">Architecture</a>
            </div>
            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>B</h4>
              <a href="<?php echo e(url('categories/balustrading')); ?>" class="nav-text">Balustrading</a>
              <a href="<?php echo e(url('categories/blinds')); ?>" class="nav-text">Blinds</a>
              <a href="<?php echo e(url('categories/building-designer')); ?>" class="nav-text">Building Designer</a>
              <a href="<?php echo e(url('categories/bamboo-flooring')); ?>" class="nav-text">Bamboo Flooring</a>
              <a href="<?php echo e(url('categories/bricklaying')); ?>" class="nav-text">Bricklaying</a>
              <a href="<?php echo e(url('categories/building-supplies')); ?>" class="nav-text">Building Supplies</a>
              <a href="<?php echo e(url('categories/bath-and-basin-resurfacing')); ?>" class="nav-text">Bath & Basin Resurfacing</a>
              <a href="<?php echo e(url('categories/building-certifiers')); ?>" class="nav-text">Building Certifiers</a>
              <a href="<?php echo e(url('categories/building-surveyors')); ?>" class="nav-text">Building Surveyors</a>
              <a href="<?php echo e(url('categories/bathroom-accessories')); ?>" class="nav-text">Bathroom Accessories</a>
              <a href="<?php echo e(url('categories/building-consultants')); ?>" class="nav-text">Building Consultants</a>
            </div>
            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>C</h4>
              <a href="<?php echo e(url('categories/cabinet-making')); ?>" class="nav-text">Cabinet Making</a>
              <a href="<?php echo e(url('categories/ceilings')); ?>" class="nav-text">Ceilings</a>
              <a href="<?php echo e(url('categories/concrete-kerbs')); ?>" class="nav-text">Concrete Kerbs</a>
              <a href="<?php echo e(url('categories/carpet-repair-and-laying')); ?>" class="nav-text">Carpet Repair & Laying</a>
              <a href="<?php echo e(url('categories/chimney-sweepers')); ?>" class="nav-text">Chimney Sweepers</a>
              <a href="<?php echo e(url('categories/concrete-resurfacing')); ?>" class="nav-text">Concrete Resurfacing</a>
              <a href="<?php echo e(url('categories/carpets')); ?>" class="nav-text">Carpets</a>
              <a href="<?php echo e(url('categories/cladding')); ?>" class="nav-text">Cladding</a>
              <a href="<?php echo e(url('categories/curtains')); ?>" class="nav-text">Curtains</a>
              <a href="<?php echo e(url('categories/carports')); ?>" class="nav-text">Carports</a>
              <a href="<?php echo e(url('categories/cleaning-services-commercial')); ?>" class="nav-text">Cleaning Services - Commercial</a>
            </div>
            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>D</h4>
              <a href="<?php echo e(url('categories/damp-proofing')); ?>" class="nav-text">Damp Proofing</a>
              <a href="<?php echo e(url('categories/demolition')); ?>" class="nav-text">Demolition</a>
              <a href="<?php echo e(url('categories/door-suppliers')); ?>" class="nav-text">Door Suppliers</a>
            </div>
          </div>

          <div class="dropdown-divider"></div>

          <div class="row px-5">
            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>E</h4>
              <a href="<?php echo e(url('categories/equipment-hire')); ?>" class="nav-text">Equipment Hire</a>
              <a href="<?php echo e(url('categories/excavation')); ?>" class="nav-text">Excavation</a>
              <a href="<?php echo e(url('categories/extensions-and-additions')); ?>" class="nav-text">Extensions & Additions</a>
            </div>

            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>F</h4>
              <a href="<?php echo e(url('categories/feng-shui')); ?>" class="nav-text">Feng Shui</a>
              <a href="<?php echo e(url('categories/floor-coatings')); ?>" class="nav-text">Floor Coatings</a>
              <a href="<?php echo e(url('categories/flyscreens')); ?>" class="nav-text">Flyscreens</a>
              <a href="<?php echo e(url('categories/furniture-custom-design')); ?>" class="nav-text">Furniture - Custom Design</a>
            </div>

            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>G</h4>
              <a href="<?php echo e(url('categories/garages')); ?>" class="nav-text">Garages</a>
              <a href="<?php echo e(url('categories/gates')); ?>" class="nav-text">Gates</a>
              <a href="<?php echo e(url('categories/gutter-protection')); ?>" class="nav-text">Gutter Protection</a>
              <a href="<?php echo e(url('categories/garden-designer')); ?>" class="nav-text">Garden Designer</a>
              <a href="<?php echo e(url('categories/gazebo')); ?>" class="nav-text">Gazebo</a>
              <a href="<?php echo e(url('categories/garden-maintenance')); ?>" class="nav-text">Garden Maintenance</a>
              <a href="<?php echo e(url('categories/gas-fitters')); ?>" class="nav-text">Gas Fitters</a>
              <a href="<?php echo e(url('categories/gutter-cleaning')); ?>" class="nav-text">Gutter Cleaning</a>
            </div>

            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>H</h4>
              <a href="<?php echo e(url('categories/handrails')); ?>" class="nav-text">Handrails</a>
              <a href="<?php echo e(url('categories/home-security-products')); ?>" class="nav-text">Home Security Products</a>
              <a href="<?php echo e(url('categories/heaters')); ?>" class="nav-text">Heaters</a>
              <a href="<?php echo e(url('categories/home-theatre')); ?>" class="nav-text">Home Theatre</a>
              <a href="<?php echo e(url('categories/heating-systems')); ?>" class="nav-text">Heating Systems</a>
              <a href="<?php echo e(url('categories/homewares')); ?>" class="nav-text">Homewares</a>
              <a href="<?php echo e(url('categories/home-automation')); ?>" class="nav-text">Home Automation</a>
              <a href="<?php echo e(url('categories/hot-water-systems')); ?>" class="nav-text">Hot Water Systems</a>
            </div>
          </div>

          <div class="dropdown-divider"></div>

          <div class="row px-5">
            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>I</h4>
              <a href="<?php echo e(url('categories/ikea-bathrooms')); ?>" class="nav-text">IKEA Bathrooms</a>
              <a href="<?php echo e(url('categories/inspections-pest')); ?>" class="nav-text">Inspections - Pest</a>
              <a href="<?php echo e(url('categories/irrigation-systems')); ?>" class="nav-text">Irrigation Systems</a>
              <a href="<?php echo e(url('categories/ikea-kitchen-installers')); ?>" class="nav-text">IKEA Kitchen Installers</a>
              <a href="<?php echo e(url('categories/insulation')); ?>" class="nav-text">Insulation</a>
              <a href="<?php echo e(url('categories/ikea-lighting-installation-and-assembly')); ?>" class="nav-text">IKEA Lighting Installation and Assembly</a>
              <a href="<?php echo e(url('categories/interior-decorating')); ?>" class="nav-text">Interior Decorating</a>
              <a href="<?php echo e(url('categories/inspections-building')); ?>" class="nav-text">Inspections - Building</a>
              <a href="<?php echo e(url('categories/interior-designer')); ?>" class="nav-text">Interior Designer</a>
            </div>

            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>J</h4>
              <a href="<?php echo e(url('categories/joinery')); ?>" class="nav-text">Joinery</a>
            </div>

            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>K</h4>
              <a href="<?php echo e(url('categories/kitchen-design')); ?>" class="nav-text">Kitchen Design</a>
            </div>

            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>L</h4>
              <a href="<?php echo e(url('categories/landscape-architecture')); ?>" class="nav-text">Landscape Architecture</a>
              <a href="<?php echo e(url('categories/limestone')); ?>" class="nav-text">Limestone</a>
              <a href="<?php echo e(url('categories/lawn-and-turf')); ?>" class="nav-text">Lawn & Turf</a>
              <a href="<?php echo e(url('categories/locksmiths')); ?>"class="nav-text">Locksmiths</a>
              <a href="<?php echo e(url('categories/lawn-mowing')); ?>" class="nav-text">Lawn Mowing</a>
              <a href="<?php echo e(url('categories/lighting')); ?>" class="nav-text">Lighting</a>
            </div>
          </div>

          <div class="dropdown-divider"></div>

          <div class="row px-5">
            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>M</h4>
              <a href="<?php echo e(url('categories/mirrors')); ?>" class="nav-text">Mirrors</a>
            </div>

            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>P</h4>
              <a href="<?php echo e(url('categories/patios')); ?>" class="nav-text">Patios</a>
              <a href="<?php echo e(url('categories/pool-heating')); ?>" class="nav-text">Pool Heating</a>
              <a href="<?php echo e(url('categories/professional-organisers')); ?>" class="nav-text">Professional Organisers</a>
              <a href="<?php echo e(url('categories/pergolas')); ?>" class="nav-text">Pergolas</a>
              <a href="<?php echo e(url('categories/pool-maintenance')); ?>" class="nav-text">Pool Maintenance</a>
              <a href="<?php echo e(url('categories/project-management')); ?>" class="nav-text">Project Management</a>
              <a href="<?php echo e(url('categories/pool-builders')); ?>" class="nav-text">Pool Builders</a>
              <a href="<?php echo e(url('categories/pressure-cleaning')); ?>" class="nav-text">Pressure Cleaning</a>
              <a href="<?php echo e(url('categories/pool-fencing')); ?>" class="nav-text">Pool Fencing</a>
              <a href="<?php echo e(url('categories/privacy-screens')); ?>" class="nav-text">Privacy Screens</a>
            </div>

            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>R</h4>
              <a href="<?php echo e(url('categories/rainwater-tanks')); ?>" class="nav-text">Rainwater Tanks</a>
              <a href="<?php echo e(url('categories/render')); ?>" class="nav-text">Render</a>
              <a href="<?php echo e(url('categories/roller-shutters')); ?>" class="nav-text">Roller Shutters</a>
              <a href="<?php echo e(url('categories/rubbish-removal')); ?>" class="nav-text">Rubbish Removal</a>
            </div>

            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>S</h4>
              <a href="<?php echo e(url('categories/scaffolding')); ?>" class="nav-text">Scaffolding</a>
              <a href="<?php echo e(url('categories/shopfitters')); ?>" class="nav-text">Shopfitters</a>
              <a href="<?php echo e(url('categories/skylights')); ?>" class="nav-text">Skylights</a>
              <a href="<?php echo e(url('categories/staircases')); ?>" class="nav-text">Staircases</a>
              <a href="<?php echo e(url('categories/security')); ?>" class="nav-text">Security</a>
              <a href="<?php echo e(url('categories/shower-repairs')); ?>" class="nav-text">Shower Repairs</a>
              <a href="<?php echo e(url('categories/solar-power')); ?>" class="nav-text">Solar Power</a>
              <a href="<?php echo e(url('categories/stonemasonry')); ?>" class="nav-text">Stonemasonry</a>
              <a href="<?php echo e(url('categories/shades-and-sails')); ?>" class="nav-text">Shades & Sails</a>
              <a href="<?php echo e(url('categories/shower-screens')); ?>" class="nav-text">Shower Screens</a>
              <a href="<?php echo e(url('categories/splashbacks')); ?>" class="nav-text">Splashbacks</a>
              <a href="<?php echo e(url('categories/storage')); ?>" class="nav-text">Storage</a>
              <a href="<?php echo e(url('categories/sheds')); ?>" class="nav-text">Sheds</a>
              <a href="<?php echo e(url('categories/skip-and-truck-hire')); ?>" class="nav-text">Skip & Truck Hire</a>
              <a href="<?php echo e(url('categories/stained-glass')); ?>" class="nav-text">Stained Glass</a>
              <a href="<?php echo e(url('categories/surveyors')); ?>" class="nav-text">Surveyors</a>
            </div>
          </div>

          <div class="dropdown-divider"></div>

          <div class="row px-5">
            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>T</h4>
              <a href="<?php echo e(url('categories/timber-flooring')); ?>" class="nav-text">Timber Flooring</a>
              <a href="<?php echo e(url('categories/town-planning')); ?>" class="nav-text">Town Planning </a>
              <a href="<?php echo e(url('categories/tree-felling')); ?>" class="nav-text" class="nav_drop">Tree Felling</a>
            </div>

            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>U</h4>
              <a href="<?php echo e(url('categories/underfloor-heating')); ?>" class="nav-text">Underfloor Heating</a>
              <a href="<?php echo e(url('categories/underpinning')); ?>" class="nav-text">Underpinning</a>
              <a href="<?php echo e(url('categories/upholstery-repair')); ?>" class="nav-text">Upholstery Repair</a>
            </div>

            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>V</h4>
              <a href="<?php echo e(url('categories/ventilation')); ?>" class="nav-text">Ventilation</a>
              <a href="<?php echo e(url('categories/verandahs')); ?>" class="nav-text">Verandahs</a>
              <a href="<?php echo e(url('categories/vinyl-and-laminate')); ?>" class="nav-text">Vinyl & Laminate</a>
            </div>

            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
              <h4>W</h4>
              <a href="<?php echo e(url('categories/wallpapering')); ?>" class="nav-text">Wallpapering</a>
              <a href="<?php echo e(url('categories/window-repairs')); ?>" class="nav-text">Window Repairs</a>
              <a href="<?php echo e(url('categories/wardrobes')); ?>" class="nav-text">Wardrobes</a>
              <a href="<?php echo e(url('categories/window-shutters')); ?>" class="nav-text">Window Shutters</a>
              <a href="<?php echo e(url('categories/waterproofing')); ?>" class="nav-text">Waterproofing</a>
              <a href="<?php echo e(url('categories/window-tinting')); ?>" class="nav-text">Window Tinting</a>
              <a href="<?php echo e(url('categories/window-cleaning')); ?>" class="nav-text">Window Cleaning</a>
              <a href="<?php echo e(url('categories/windows')); ?>" class="nav-text">Windows</a>
            </div>
          </div>

        </div>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('costguide')); ?>">Cost Guide</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('blog')); ?>">Blog</a>
      </li>

      <?php if(auth()->guard()->guest()): ?>
      <li class="nav-item nav-account">
        <a class="nav-link" href="<?php echo e(route('login')); ?>">Login <i class="fa fa-sign-in" aria-hidden="true"></i></a>
      </li>

      <li class="nav-item nav-account">
        <a class="nav-link" href="/user/signup">Signup <i class="fa fa-user-plus" aria-hidden="true"></i></a>
      </li>

      <?php else: ?>
      <li class="nav-item dropdown dropnav">
        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
        <img src="<?php echo e(Auth::user()->avatar); ?>" class="navbar-circle"> 
          <?php echo e(Auth::user()->username); ?> <span class="caret"></span>
        </a>
        <div class="dropdown-menu drop-menu-position" aria-labelledby="navbarDropdown">
          <div class="row pl-3">
            <div class="col-12 col-sm-12 col-md-12 col-lg-12">
              <?php if(Auth::user()->role_id == 1): ?>
                <a class="text-white" href="<?php echo e(route('contractor.dashboard')); ?>">
              <?php elseif(Auth::user()->role_id == 2): ?>
                <a class="text-white" href="<?php echo e(route('homeowner.dashboard')); ?>">
              <?php elseif(Auth::user()->role_id == 3): ?>
                <a class="text-white" href="<?php echo e(route('marketer.dashboard')); ?>">
              <?php else: ?>
                <a class="text-white" href="<?php echo e(route('trainer.dashboard')); ?>">
              <?php endif; ?>
              <?php echo e(__('My Dashboard')); ?><i class="" aria-hidden="true"></i>
              </a>
            </div>
          </div>

          <div class="dropdown-divider"></div>
          
          <div class="row pl-3">
            <div class="col-12 col-sm-12 col-md-12 col-lg-12">
              <a class="text-white" href="<?php echo e(route('logout')); ?>" 
                onclick="event.preventDefault();
                document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?><i class="fa fa-sign-out-alt" aria-hidden="true"></i>
              </a>
            </div>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"> <?php echo csrf_field(); ?>
            </form>
          </div>
        </div>
      </li>
      <?php endif; ?>
    </ul>

    
  </div>
</nav>
<?php /**PATH C:\Users\DEEONE\Desktop\Laravel - 365home Ipage\365homeimprovement\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>