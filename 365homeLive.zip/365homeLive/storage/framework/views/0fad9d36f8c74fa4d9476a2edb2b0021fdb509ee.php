<?php $__env->startSection('heading'); ?>
  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section>
    <div class="container-fluid p-0">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <div class="banner-head">
            <img class="img-responsive img-fluid banner-bg" src="<?php echo e(URL::to('/')); ?>/img/page-banner.jpg" alt="Page Banner"/>
            <div class="banner-overlay pb-0">
            <h1 class="text-white text-center" style="font-size: 1.4rem; font-weight: 700">SELL YOUR <span class="text-orange">PRODUCTS </span>HERE</h1>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container mb-5">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <div class="alert alert-danger mt-3 mb-5">
            <span class="mr-2"><a href="<?php echo e(url('/')); ?>" class="text-black">Home</a></span>
            <i class="fa fa-angle-double-right text-black"></i>
            <span class="mx-2"><a href="<?php echo e(url('#')); ?>" class="text-black">Market</a></span>
          </div>
        </div>

        <div class="col-12 col-sm-12 col-md-12 col-lg-12 mb-5">
          <h3 style="font-weight: 600" class="text-center mb-4">SELL ON 365 HOME IMPROVEMENT</h3>
          <p class="text-jusify">Millions of home owners can’t wait to see what you have in store. Hausworth Nigeria Limited owners of 365 Home Improvementseeks to work with leading building materials producers and sellers in Nigeria and beyond in the marketing and sales of their products on our platform.
          Published online, 365Home Improvement is the one stop shop for property listing, building materials sales and removers industry in Nigeria.
          </p>
        </div>

        <div class ="col-12 col-sm-12 col-md-12 col-lg-12">
          <h5 class="text-center mb-4"> BENEFITS OF BECOMING A CONTENT PROVIDER ON OUR PLATFORM</h5>
          <ol>
            <li style="font-size: 1.1rem">
              <p>MORE EARNINGS</p>
              <p>Supplier set their price and earns ninety percent (90%) of the cost price of their product on our platform. </p>
            </li>
            <li style="font-size: 1.1rem">
              <p>GREATER MARKETING AND PUBLICITY</p>
              <p>Hausworth Nigeria Limited would ensure maximum marketing and publicity of your products on different platforms both online and offline.</p>
            </li>
            <li style="font-size: 1.1rem">
               <p>PAYMENT</p>
               <p>The amount earned can be easily seen along with your payment and earning history (transaction history).
              Payment would be made into your account once the threshold of thirty thousand (N 30,000) is met.
              </p>
            </li>
          </ol>

          <h5 class="text-center pt-5">OTHER BENEFITS INCLUDES</h5>
          <p class="ml-4">Supplier set their price and earns ninety percent (90%) of the cost price of their product on our platform. </p>
          <ul>
            </li>
            <li>Be represented by knowledgeable sales professionals who know your products and the customers.</li>
            <li>Pay no fees to join.</li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <section class="my-5">
    <div class="container">
      
      <div class="row">
        <div class="col-12">
          <h5 class="text-center">BECOME A CONTENT PROVIDER</h5>
        </div>
      </div>
       
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <h5 class="text-center">To get the process started, fill out the form below, and we’ll begin the review.</h5>
        </div>

        <div class="col-md-8 mx-auto bg-white">
          

          <form action="#" method="POST" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>


          <div class="form-group my-3">
            <label for="">FirstName</label>
            <input type="text" name="name" placeholder="First Name" class="form-control mb-3">
          </div>

          <div class="form-group my-3">
            <label for="">Last Name:</label>
            <input type="text" name="name" placeholder="Last name" class="form-control mb-3">
          </div>

          <div class="form-group my-3">
            <label for="">Company Name:</label>
            <input type="text" name="name" placeholder="Enter company name" class="form-control mb-3">
          </div>

          <div class="form-group my-3">
            <label for="">Address:</label>
            <input type="text" name="name" placeholder="Enter Adress" class="form-control mb-3">
          </div>

          <div class="form-group my-3">
            <label for="">Telephone Number:</label>
            <input type="text" name="name" placeholder="Enterphone number" class="form-control mb-3">
          </div>

          <div class="form-group my-3">
            <label for="">Email:</label>
            <input type="text" name="name" placeholder="Enter email" class="form-control mb-3">
          </div>
          
          <div class="form-group my-3">
            <label for="">Website:</label>
            <input type="text" name="name" placeholder="Enter your website" class="form-control mb-3">
          </div>

          <div class="form-group my-3">
            <label for="">Attach and Upload your products :</label> <br>
            <input type="file" name="product1" class="form-control-file">
            <input type="file" name="product2" class="form-control-file my-3">
            <input type="file" name="product3" class="form-control-file">
          </div>

          <div class="form-group my-3">
            <button type="submit" name="getQuote" id="" class="btn btn-orange">Get Started</button>   
          </div>
          </form>
        </div>
      </div>
    </div>
  </section>

  <section class="mt-5 border-bottom border-links">
    <div class="container">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <h3 class="title-a text-center mb-3">OUR<span class="text-orange ml-2">GALLERY</span></h3>
        </div>
      </div>
  	</div>
  </section>

  <section class="section-kitchen nav-arrow-a border-bottom border-links">
    <div class="container py-3 mb-3">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a mb-3">Kitchen and Dining</h2>
            </div>
          </div>
        </div>
      </div>

      <div id="market-carousel" class="owl-carousel owl-arrow">
        <div class="carousel-item-a">
          <div class="market-box">
            <div class="row">
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Kitchen & Dining Furniture</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Tile</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Kitchen Fixtures</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Kitchen Appliances</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Tabletop</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Kitchen Storage & Organization</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Cabinet & Drawer Hardware</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Kitchen & Cabinet Lighting</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Cookware & Bakeware</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py- text-center">Kitchen Tools & Gadgets</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section-bath nav-arrow-a border-bottom border-links">
    <div class="container py-3 mb-3">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a mb-3">Bath Products</h2>
            </div>
          </div>
        </div>
      </div>

      <div id="" class="">
        <div class="carousel-item-a">
          <div class="market-box">
            <div class="row">
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Bathroom Vanities</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Bathroom Vanity Lighting</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Tile</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Showers</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Bathtubs</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Bathroom Faucets</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Bathroom Sinks</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Bathroom Accessories</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Bath Linens</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Medicine Cabinets</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section-bedroom nav-arrow-a border-bottom border-links">
    <div class="container py-3 mb-3">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a mb-3">Bedroom Products</h2>
            </div>
          </div>
        </div>
      </div>

      <div id="" class="">
        <div class="carousel-item-a">
          <div class="market-box">
            <div class="row">
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Beds & Headboards</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Bedding</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py- text-center">Bedroom Decor</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Lamps</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Dressers</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Nightstands & Bedside Tables</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Closet Storage</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Futons</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Bedroom Benches</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Chaise Lounge Chairs</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section-bath nav-arrow-a border-bottom border-links">
    <div class="container py-3 mb-3">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a mb-3">Living Products</h2>
            </div>
          </div>
        </div>
      </div>

      <div id="" class="">
        <div class="carousel-item-a">
          <div class="market-box">
            <div class="row">
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Home Decor</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Coffee & Accent Tables</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Rugs</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Sofas & Sectionals</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Armchairs & Accent Chairs</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Lamps</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Artwork</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Media Storage</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Bookcases</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Fireplaces & Accessories</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section-bedroom nav-arrow-a border-bottom border-links">
    <div class="container py-3 mb-3">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a mb-3">Lighting</h2>
            </div>
          </div>
        </div>
      </div>

      <div id="" class="">
        <div class="carousel-item-a">
          <div class="market-box">
            <div class="row">
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Chandeliers</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Pendant Lighting</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py- text-center">Bathroom Vanity Lighting</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Wall Sconces</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Flush-Mount Ceiling Lighting</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Ceiling Fans</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Table Lamps</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Floor Lamps</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Kitchen & Cabinet Lighting</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Outdoor Lighting</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section-bath nav-arrow-a border-bottom border-links">
    <div class="container py-3 mb-3">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a mb-3">Furniture</h2>
            </div>
          </div>
        </div>
      </div>

      <div id="" class="">
        <div class="carousel-item-a">
          <div class="market-box">
            <div class="row">
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Living Room Furniture</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Kitchen & Dining Furniture</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Bathroom Storage & Vanities</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Bedroom Furniture</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Home Office Furniture</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Storage Furniture</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Outdoor Furniture</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section-bedroom nav-arrow-a border-bottom border-links">
    <div class="container py-3 mb-3">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a mb-3">Home Decor</h2>
            </div>
          </div>
        </div>
      </div>

      <div id="" class="">
        <div class="carousel-item-a">
          <div class="market-box">
            <div class="row">
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Decorative Accents</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Rugs</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py- text-center">Mirrors</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Wall Decor</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Artwork</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Pillows & Throws</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Window Treatments</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section-bath nav-arrow-a border-bottom border-links">
    <div class="container py-3 mb-3">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a mb-3">Home Improvement</h2>
            </div>
          </div>
        </div>
      </div>

      <div id="" class="">
        <div class="carousel-item-a">
          <div class="market-box">
            <div class="row">
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Bathroom Fixtures</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Kitchen Fixtures</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Tile</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Hardware</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Heating & Cooling</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Building Materials</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Tools & Equipment</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section-bedroom nav-arrow-a border-bottom border-links">
    <div class="container py-3 mb-3">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a mb-3">Outdoor Products</h2>
            </div>
          </div>
        </div>
      </div>

      <div id="" class="">
        <div class="carousel-item-a">
          <div class="market-box">
            <div class="row">
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Outdoor Furniture</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Outdoor Decor</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py- text-center">Outdoor Lighting</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Pool & Spa</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Lawn & Garden</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Outdoor Structures</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Outdoor Cooking</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section-bath nav-arrow-a border-bottom border-links">
    <div class="container py-3 mb-3">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a mb-3">Storage & Organization</h2>
            </div>
          </div>
        </div>
      </div>

      <div id="" class="">
        <div class="carousel-item-a">
          <div class="market-box">
            <div class="row d-flex justify-content-center">
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Media Storage</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Office Storage</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Storage Furniture</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section-bedroom nav-arrow-a border-bottom border-links">
    <div class="container py-3 mb-3">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a mb-3">Housekeeping & Laundry</h2>
            </div>
          </div>
        </div>
      </div>

      <div id="" class="">
        <div class="carousel-item-a">
          <div class="market-box">
            <div class="row d-flex justify-content-center">
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Ironing Boards</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Irons</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py- text-center">Laundry Hampers</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section-bedroom nav-arrow-a border-bottom border-links">
    <div class="container py-3 mb-3">
      <div class="row">
        <div class="col-md-12">
          <div class="title-wrap d-flex justify-content-between">
            <div class="title-box">
              <h2 class="title-a mb-3">Holiday Decor</h2>
            </div>
          </div>
        </div>
      </div>

      <div id="" class="">
        <div class="carousel-item-a">
          <div class="market-box">
            <div class="row d-flex justify-content-center">
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Holiday Accents & Figurines</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py-2 text-center">Holiday Lighting</p>
                </div>
              </div>
              <div class="col-4 col-sm-4 col-md-3 col-lg-2">
                <div class="testimonial-img">
                  <img src="img/socials/case_study_flat_screen_monitor_on_wall.jpg" alt="" class="img-fluid">
                  <p class="py- text-center">Wreaths & Garlands</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <?php echo $__env->make('layouts.footer-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DEEONE\Desktop\Homeimprovement-User&Admin\resources\views/links/market-place.blade.php ENDPATH**/ ?>