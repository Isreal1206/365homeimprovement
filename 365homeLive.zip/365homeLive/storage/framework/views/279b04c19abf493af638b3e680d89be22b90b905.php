<!DOCTYPE html>
<html lang="en">

<head>
  <!--header start-->
  <?php echo $__env->make('layouts.backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!--header end-->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--navbar start-->
    <?php echo $__env->make('layouts.backend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--navbar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <?php echo $__env->make('layouts.backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="row content-panel">
              <div class="profile-text">
                <h3>Gallery</h3>
              </div>
              <!-- /panel-heading -->
              <div class="panel-body">
                <div class="tab-content">
                  <!-- /tab-pane -->
                  <div id="edit" class="tab-pane active">
                    <div class="row site-min-height">
                      <div class="col-lg-8 col-lg-offset-2 detailed">
                        <h4 class="mb">Upload Products</h4>
                        <?php if($flash = session('success')): ?>
                          <div class="alert alert-success" role="alert">
                            <?php echo e($flash); ?>

                          </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('marketer.upload_images')); ?>" role="form" class="form-horizontal" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                          <div class="form-group">
                            <label class="col-lg-3 control-label"> First Product:</label>
                            <div class="col-lg-7">
                              <input type="file" id="products1" class="file-pos" name="products1">
                              <small class="text-danger"><?php echo e($errors->first('products1')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label"> Second Product:</label>
                            <div class="col-lg-7">
                              <input type="file" id="products2" class="file-pos" name="products2">
                              <small class="text-danger"><?php echo e($errors->first('products2')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label"> Third Product:</label>
                            <div class="col-lg-7">
                              <input type="file" id="products3" class="file-pos" name="products3">
                              <small class="text-danger"><?php echo e($errors->first('products3')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <div class="col-lg-offset-3 col-lg-7">
                              <button class="btn btn-theme" type="submit">Save</button>
                              <button class="btn btn-theme04" type="reset">Cancel</button>
                            </div>
                          </div>
                        </form>

                        <h4 class="mt-100">Display Products</h4>
                        <div class="col-lg-4 height-200 border-custom">
                          <img src="" class="img-responsive img-fluid">
                        </div>
                        <div class="col-lg-4 height-200 border-custom">
                          <img src="" class="img-responsive img-fluid">
                        </div>
                        <div class="col-lg-4 height-200 border-custom">
                          <img src="" class="img-responsive img-fluid">
                        </div>
                      </div>
                      <!-- /col-lg-8 -->
                    </div>
                    <!-- /row -->
                  </div>
                  <!-- /tab-pane -->
                </div>
                <!-- /tab-content -->
              </div>
              <!-- /panel-body -->
            </div>
            <!-- /col-lg-12 -->
          </div>
          <!-- /row -->
        </div>
        <!-- /container -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    
    <!--footer start-->
    <?php echo $__env->make('layouts.backend.footer-copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--footer end-->
  </section>

  <!-- js placed at the end of the document so the pages load faster -->
  <?php echo $__env->make('layouts.backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\DEEONE\Desktop\Laravel - 365home Ipage\365homeimprovement\resources\views/user/marketers/upload_images.blade.php ENDPATH**/ ?>