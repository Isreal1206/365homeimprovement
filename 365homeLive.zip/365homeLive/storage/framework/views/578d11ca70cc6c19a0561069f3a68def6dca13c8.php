<!DOCTYPE html>
<html lang="en">

<head>
  <!--header start-->
  <?php echo $__env->make('layouts.backend.admin-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!--header end-->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--navbar start-->
    <?php echo $__env->make('layouts.backend.admin-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--navbar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <?php echo $__env->make('layouts.backend.admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
            <!--CUSTOM CHART START -->
            <div class="row content-panel site-min-height">
              <div class="panel-heading">
                <ul class="nav nav-tabs nav-justified">
                  <li  class="active">
                    <a data-toggle="tab" href="#categories">All Categories</a>
                  </li>
                  <li>
                    <a data-toggle="tab" href="#edit">Edit</a>
                  </li>
                </ul>
              </div>

              <div class="panel-body">
                <div class="tab-content">
                  <div id="categories" class="tab-pane active">
                    <div class="row">
                      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 mb">
                        <div class="table-responsive">
                          <table class="table table-bordered table-striped">
                            <thead>
                              <tr class="text-center">
                                <th>#</th>
                                <th>Name</th>
                                <th>Slug</th>
                                <th colspan="2">Action</th>
                              </tr>
                            </thead>

                            <tbody>
                              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <th><?php echo e($category->id); ?></th>
                                <td><?php echo e($category->name); ?></td>
                                <td><?php echo e($category->slug); ?></td>
                                <td class="text-center"><button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button></td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                          </table>
                        </div>

                        <div class="d-flex justify-content-center">
                          <?php echo $categories->links();; ?>

                        </div>
                      </div>
                    </div>
                  </div>

                  <div id="edit" class="tab-pane">
                    <div class="row">
                      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <div class="table-responsive">
                          <table class="table table-bordered table-striped">
                            <thead>
                              <tr class="text-center">
                                <th>#</th>
                                <th>Name</th>
                                <th>Slug</th>
                                <th colspan="2">Action</th>
                              </tr>
                            </thead>

                            <tbody>
                              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <form action="<?php echo e(route('admin.category.edit', $category->id)); ?>" method="POST">
                              <?php echo csrf_field(); ?>
                              <tr>
                                <th><?php echo e($category->id); ?></th>
                                <td>
                                  <input type="text" name="name" value="<?php echo e($category->name); ?>" class="form-control bord">
                                  <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
                                </td>
                                <td>
                                  <input type="text" name="slug" value="<?php echo e($category->slug); ?>" class="form-control bord">
                                  <small class="text-danger"><?php echo e($errors->first('slug')); ?></small>
                                </td>
                                <td class="text-center"><button type="submit" class="btn btn-sm btn-success"><i class="fa fa-save"></i></button></td>
                              </tr>
                              </form>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                          </table>
                        </div>

                        <div class="d-flex justify-content-center">
                          <?php echo $categories->links();; ?>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>           
          </div>
          <!-- /col-lg-9 END SECTION MIDDLE -->
          <!-- **********************************************************************************************************************************************************
              RIGHT SIDEBAR CONTENT
              *********************************************************************************************************************************************************** -->
          <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 ds">
            <!--RIGHT SIDEBAR-->
            <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <?php if(session('success')): ?>
                  <div class="alert alert-success text-center">
                    <i class='fa fa-check'></i> <?php echo e(session('success')); ?>

                  </div>
                <?php endif; ?>
                <div class="bg-primary" style="padding: 10px">
                  <form action = "<?php echo e(route('admin.category.store')); ?>" method = "POST" >
                  <?php echo csrf_field(); ?>
                    <h4 class="text-center">Create Category</h4>
                    <div class="form-group">
                      <input type="text" placeholder="Enter Name" id="name" class="form-control" name="name" autocomplete="name">
                      <small class="text-danger"><?php echo e($errors->first('name')); ?></small>
                    </div>
                    <div class="form-group">
                      <input type="text" placeholder="Enter Slug" id="slug" class="form-control" name="slug" autocomplete="slug">
                      <small class="text-danger"><?php echo e($errors->first('slug')); ?></small>
                    </div>
                    <div class="form-group">
                      <button class="btn btn-block btn-orange" type="submit">Submit</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>

            <div class="row mt">
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="calc">
                  <p class="calc-label">365HI CALC</p>
                  <p class="screen"><input type="text" name="" class="form-control" id="d" readonly></p>
                  <div class="keys">
                    <p>
                      
                      <button onclick='sqr()'>X<sup>2</sup></button>
                      <button onclick='sqrt()'>&#8730</button>
                      <button onclick='back()'>&#8592</button>
                      <button onclick='c("")'>AC</button>
                    </p>
                    <p>
                      <button onclick='math("7")'>7</button>
                      <button onclick='math("8")'>8</button>
                      <button onclick='math("9")'>9</button>
                      <button onclick='math("/")'>/</button>
                    </p>
                    <p>
                      <button onclick='math("4")'>4</button>
                      <button onclick='math("5")'>5</button>
                      <button onclick='math("6")'>6</button>
                      <button onclick='math("*")'>*</button>
                    </p>
                    <p>
                      <button onclick='math("1")'>1</button>
                      <button onclick='math("2")'>2</button>
                      <button onclick='math("3")'>3</button>
                      <button onclick='math("-")'>-</button>
                    </p>
                    <p>
                      <button onclick='math("0")'>0</button>
                      <button onclick='math(".")'>.</button>
                      <button onclick='e()'>=</button>
                      <button onclick='math("+")'>+</button>
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <!-- CALENDAR-->
            <div id="calendar">
              <div class="green-panel mt">
                <div class="panel-body">
                  <div id="date-popover" class="popover top" style="cursor: pointer; disadding: block; margin-left: 33%; margin-top: -50px; width: 175px;">
                    <div class="arrow"></div>
                    <h3 class="popover-title" style="disadding: none;"></h3>
                    <div id="date-popover-content" class="popover-content"></div>
                  </div>
                  <div id="my-calendar"></div>
                </div>
              </div>
            </div>
            <!-- / calendar -->
          </div>
          <!-- /col-lg-3 -->
        </div>
        <!-- /row -->
      </section>
    </section>
    <!--main content end-->

    <!--footer start-->
    <?php echo $__env->make('layouts.backend.footer-copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--footer end-->
  </section>

  <!-- js placed at the end of the document so the pages load faster -->
  <?php echo $__env->make('layouts.backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <script type="text/javascript">
    function modus(x, y) {
      //square function.
      var x = document.getElementById("d").value;
      var y = document.getElementById("d").value;
      document.getElementById("d").value = Math.floor(x / y), x % y;
    }
    function sqr() {
      //square function.
      var num = document.getElementById("d").value;
      document.getElementById("d").value = Math.pow(num, 2);
    }
    function sqrt() {
      //square function.
      var num = document.getElementById("d").value;
      document.getElementById("d").value = Math.sqrt(num);
    }
    function c(val) {
      document.getElementById("d").value=val;
    }
    function math(val) {
      document.getElementById("d").value+=val;
    }
    function back() {
      //delete last letter function.
      var value = document.getElementById("d").value;
      document.getElementById("d").value = value.substr(0, value.length - 1);
    }
    function e() { 
      try { 
        c(eval(document.getElementById("d").value)) 
      } 
      catch(e) {
        c('Error') 
      } 
    }
  </script>

</body>

</html>
<?php /**PATH E:\Laravel - 365home\Homeimprovement\resources\views/admin/categories.blade.php ENDPATH**/ ?>