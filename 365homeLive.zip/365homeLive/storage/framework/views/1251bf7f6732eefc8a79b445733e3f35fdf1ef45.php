<?php $__env->startSection('heading'); ?>
  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section>
    <div class="container-fluid p-0">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <div class="banner-head">
            <img class="img-responsive img-fluid banner-bg" src="<?php echo e(URL::to('/')); ?>/img/page-banner.jpg" alt="Page Banner"/>
            <div class="banner-overlay pb-0">
            <h1 class="text-white text-center" style="font-size: 1.4rem; font-weight: 700"><span class="text-orange">ABOUT</span> 365HOMEIMPROVEMENT</h1>
            </div>
          </div>
        </div>
      </div>
    </div>
  
    <div class="container">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <div class="alert alert-dark mt-3 mb-5">
            <span class="mr-2"><a href="<?php echo e(url('/')); ?>">Home</a></span>
            <i class="fa fa-angle-double-right"></i>
            <span class="mx-2"><a href="<?php echo e(url('#')); ?>">About</a></span>
          </div>
        </div>
      </div>
        
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h1 class="text-title mb-4">Template</h1>
          <div class="row">
          <?php $__currentLoopData = $marketers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marketer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-3">
              <p><?php echo e($marketer->id); ?></p>
              <p><?php echo e($marketer->name); ?></p>
              <p><?php echo e($marketer->sub_name); ?></p>
              <p><?php echo e($marketer->slug); ?></p>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    
    </div>
  </section>

  <?php echo $__env->make('layouts.footer-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.app-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DEEONE\Desktop\Laravel - 365home Ipage\365homeimprovement\resources\views/test.blade.php ENDPATH**/ ?>