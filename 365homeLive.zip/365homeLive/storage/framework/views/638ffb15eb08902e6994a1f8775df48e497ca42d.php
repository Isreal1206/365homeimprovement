
<?php if(count($errors) > 0): ?>

    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Errors:</strong>

        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <li><?php echo e($error); ?></li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>

<?php endif; ?>

<?php if(Session::has('post_store_success')): ?>

    <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('post_store_success')); ?>

    </div>

<?php endif; ?>

<?php if(Session::has('post_update_success')): ?>

    <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('post_update_success')); ?>

    </div>

<?php endif; ?>

<?php if(Session::has('post_delete_success')): ?>

    <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('post_delete_success')); ?>

    </div>

<?php endif; ?><?php /**PATH C:\Users\DEEONE\Desktop\Laravel - 365home Ipage\Homeimprovement\resources\views/inc/messages.blade.php ENDPATH**/ ?>