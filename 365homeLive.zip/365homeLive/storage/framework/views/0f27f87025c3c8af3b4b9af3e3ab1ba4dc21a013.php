<!DOCTYPE html>
<html lang="en">

<head>
  <!--header start-->
  <?php echo $__env->make('layouts.backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!--header end-->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--navbar start-->
    <?php echo $__env->make('layouts.backend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--navbar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <?php echo $__env->make('layouts.backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="row content-panel">
              <div class="panel-heading">
                <ul class="nav nav-tabs nav-justified">
                  <li  class="active">
                    <a data-toggle="tab" href="#edit">Edit Profile</a>
                  </li>
                  <li>
                    <a data-toggle="tab" href="#contact" class="contact-map">Contact</a>
                  </li>
                  <li>
                    <a data-toggle="tab" href="#overview">Overview</a>
                  </li>
                </ul>
              </div>
              <!-- /panel-heading -->
              <div class="panel-body">
                <div class="tab-content">

                  <!-- /tab-pane -->
                  <div id="edit" class="tab-pane active">
                    <div class="row site-min-height">
                      <div class="col-lg-8 col-lg-offset-2 detailed">
                        <h4 class="mb">Personal Information</h4>
                        <?php if($flash = session('success')): ?>
                          <div class="alert alert-success" role="alert">
                            <?php echo e($flash); ?>

                          </div>
                        <?php endif; ?>

                        <?php if(Auth::user()->role_id == 1): ?>
                        <form method="POST" action="<?php echo e(route('contractor.profile.update')); ?>" role="form" class="form-horizontal" enctype="multipart/form-data">
                        <?php elseif(Auth::user()->role_id == 2): ?>
                        <form method="POST" action="<?php echo e(route('trainer.profile.update')); ?>" role="form" class="form-horizontal" enctype="multipart/form-data">
                        <?php elseif(Auth::user()->role_id == 3): ?>
                        <form method="POST" action="<?php echo e(route('marketer.profile.update')); ?>" role="form" class="form-horizontal" enctype="multipart/form-data">
                        <?php else: ?>
                        <form method="POST" action="<?php echo e(route('homeowner.profile.update')); ?>" role="form" class="form-horizontal" enctype="multipart/form-data">
                        <?php endif; ?>
                        
                        <?php echo e(csrf_field()); ?>

                          <div class="form-group">
                            <label class="col-lg-3 control-label"> Avatar:</label>
                            <div class="col-lg-7">
                              <input type="file" id="avatar" class="file-pos" name="avatar">
                              <small class="text-danger"><?php echo e($errors->first('avatar')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Firstname:</label>
                            <div class="col-lg-7">
                              <input type="text" placeholder="<?php echo e(Auth::user()->firstname); ?>" id="firstname" class="form-control" name="firstname">
                              <small class="text-danger"><?php echo e($errors->first('firstname')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Lastname:</label>
                            <div class="col-lg-7">
                              <input type="text" placeholder="<?php echo e(Auth::user()->lastname); ?>" id="lastname" class="form-control" name="lastname">
                              <small class="text-danger"><?php echo e($errors->first('lastname')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Username:</label>
                            <div class="col-lg-7">
                              <input type="text" placeholder="<?php echo e(Auth::user()->username); ?>" id="username" class="form-control" name="username" readonly>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Email Address:</label>
                            <div class="col-lg-7">
                              <input type="email" placeholder="<?php echo e(Auth::user()->email); ?>" id="email" class="form-control" name="email" readonly>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Mobile Number:</label>
                            <div class="col-lg-7">
                              <input type="text" placeholder="<?php echo e(Auth::user()->mobile); ?>" id="mobile" class="form-control" name="mobile">
                              <small class="text-danger"><?php echo e($errors->first('mobile')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="col-lg-3 control-label">Home Address:</label>
                            <div class="col-lg-7">
                              <input type="text" placeholder="<?php echo e(Auth::user()->address); ?>" id="address" class="form-control" name="address">
                              <small class="text-danger"><?php echo e($errors->first('address')); ?></small>
                            </div>
                          </div>
                          <div class="form-group">
                            <div class="col-lg-offset-3 col-lg-7">
                              <button class="btn btn-theme" type="submit">Save</button>
                              <button class="btn btn-theme04" type="reset">Cancel</button>
                            </div>
                          </div>
                        </form>

                        <h4 class="mb mt">Reset Password</h4>
                        <?php if($error = session('error')): ?>
                          <div class="alert alert-danger" role="alert">
                              <?php echo e($error); ?>

                          </div>
                        <?php endif; ?>
                        <?php if($flash = session('resetPassword')): ?>
                          <div class="alert alert-success" role="alert">
                            <?php echo e($flash); ?>

                          </div>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('contractor.password.reset')); ?>" role="form" class="form-horizontal">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                          <label class="col-lg-3 control-label">Current Password:</label>
                          <div class="col-lg-7">
                            <input type="password" placeholder="" id="cpassword" class="form-control" name="cpassword" required autocomplete="old-password">
                            <small class="text-danger"><?php echo e($errors->first('cpassword')); ?></small>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label">Password:</label>
                          <div class="col-lg-7">
                            <input type="password" placeholder="" id="password" class="form-control" name="password" required autocomplete="new-password">
                            <small class="text-danger"><?php echo e($errors->first('password')); ?></small>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label">Confirm Password:</label>
                          <div class="col-lg-7">
                            <input type="password" placeholder="" id="confirm-password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            <small class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></small>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-lg-offset-3 col-lg-7">
                            <button class="btn btn-theme" type="submit">Confirm</button>
                            <button class="btn btn-theme04" type="reset">Cancel</button>
                          </div>
                        </div>
                        </form>
                      </div>
                      <!-- /col-lg-8 -->
                    </div>
                    <!-- /row -->
                  </div>
                  <!-- /tab-pane -->

                  <div id="contact" class="tab-pane">
                    <div class="row site-min-height">
                      <div class="col-md-6">
                        <div id="map"></div>
                      </div>
                      <!-- /col-md-6 -->
                      <div class="col-md-6 detailed">
                        <h4>Location</h4>
                        <div class="col-md-8 col-md-offset-2 mt mb">
                          <p><strong>Home Address:</strong> <?php echo e(Auth::user()->address); ?></p>
                        </div>
                        <h4>Contacts</h4>
                        <div class="col-md-8 col-md-offset-2 mt">
                          <p><strong>Mobile Number:</strong> <?php echo e(Auth::user()->mobile); ?></p>
                          <p><strong>Email:</strong> <?php echo e(Auth::user()->email); ?></p>
                        </div>
                      </div>
                      <!-- /col-md-6 -->
                    </div>
                    <!-- /row -->
                  </div>
                  <!-- /tab-pane -->

                  <div id="overview" class="tab-pane">
                    <div class="row site-min-height">

                      <div class="col-md-6">
                        <textarea rows="3" class="form-control" placeholder="Whats on your mind?"></textarea>
                        <div class="grey-style">
                          <div class="pull-left">
                            <button class="btn btn-sm btn-theme"><i class="fa fa-camera"></i></button>
                            <button class="btn btn-sm btn-theme"><i class="fa fa-map-marker"></i></button>
                          </div>
                          <div class="pull-right">
                            <button class="btn btn-sm btn-theme03">POST</button>
                          </div>
                        </div>

                        <!-- detailed -->
                        <div class="detailed mt">
                          <!-- recent-activity -->
                          <h4 class="text-primary text-center mb">PERSONAL INFORMATION</h4>
                          <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                            <tr>
                              <th>FIRSTNAME:</th>
                              <td><?php echo e(Auth::user()->firstname); ?></td>
                            </tr>
                            
                            <tr>
                              <th>LASTNAME:</th>
                              <td><?php echo e(Auth::user()->lastname); ?></td>
                            </tr>
                            
                            <tr>
                              <th>USERNAME:</th>
                              <td><?php echo e(Auth::user()->username); ?></td>
                            </tr>

                            <tr>
                              <th>EMAIL ADDRESS:</th>
                              <td><?php echo e(Auth::user()->email); ?></td>
                            </tr>
                            </table>
                          </div>
                          <!-- /recent-activity -->
                        </div>
                        <!-- /detailed -->
                      </div>
                      <!-- /col-md-6 -->
                      
                      <div class="col-md-6 detailed">
                        <!-- user-stats -->
                        <h4>User Stats</h4>
                        <div class="row centered mt mb">
                          <div class="col-sm-4">
                            <h1><i class="fa fa-money"></i></h1>
                            <h3>$0</h3>
                            <h6>LIFETIME EARNINGS</h6>
                          </div>
                          <div class="col-sm-4">
                            <h1><i class="fa fa-trophy"></i></h1>
                            <h3>2</h3>
                            <h6>COMPLETED TASKS</h6>
                          </div>
                          <div class="col-sm-4">
                            <h1><i class="fa fa-check"></i></h1>
                            <h3>1</h3>
                            <h6>CONTRACTS WON</h6>
                          </div>
                        </div>
                        <!-- /user-stats -->
                        
                        <!-- detailed -->
                        <div class="detailed mt">
                          <!-- pending-tasks -->
                          <h4>Pending Tasks</h4>
                          <div class="row centered">
                            <div class="col-md-8 col-md-offset-2">
                              <h5>Dashboard Update (40%)</h5>
                              <div class="progress">
                                <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                                  <span class="sr-only">40% Complete (success)</span>
                                </div>
                              </div>
                              <h5>Profile Update (80%)</h5>
                              <div class="progress">
                                <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                                  <span class="sr-only">80% Complete (success)</span>
                                </div>
                              </div>
                            </div>
                            <!-- /col-md-8 -->
                          </div>
                          <!-- /row -->
                          <!-- /pending-tasks -->
                        </div>
                        <!-- /detailed -->

                      </div>
                      <!-- /col-md-6 -->
                    </div>
                    <!-- /OVERVIEW -->
                  </div>
                  <!-- /tab-pane -->

                </div>
                <!-- /tab-content -->
              </div>
              <!-- /panel-body -->
            </div>
            <!-- /col-lg-12 -->
          </div>
          <!-- /row -->
        </div>
        <!-- /container -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    
    <!--footer start-->
    <?php echo $__env->make('layouts.backend.footer-copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--footer end-->
  </section>

  <!-- js placed at the end of the document so the pages load faster -->
  <?php echo $__env->make('layouts.backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\DEEONE\Desktop\Homeimprovement-Admin\resources\views/user/profile.blade.php ENDPATH**/ ?>