<?php $__env->startSection('heading'); ?>
  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section>
    <div class="container-fluid p-0">
      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
          <div class="banner-head mb-0">
            <img class="img-responsive img-fluid banner-bg" src="<?php echo e(URL::to('/')); ?>/img/page-banner.jpg" alt="Page Banner"/>
            <div class="banner-overlay2">
              <h1 class="text-white training-title" style="margin-top: 6rem">Become a <span class="text-orange">Trainer</span></h1>
              <p class="text-center text-white">@</p>
              <p class="text-center text-primary">Hausworth Nigeria Limited</p>
              <p class="text-center text-uppercase">
                <a href="<?php echo e(route('register')); ?>" class="btn btn-sm btn-orange font-w-6">signup now</a>
              </p>
            </div>
          </div>
        </div>
      </div>

      <div class="row vheight">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-9 bg-white">
          <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <h2 class="training-title my-3">Gallery</h2>
              
            </div>
          </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3" style="background: #edeced">
          <div class="row p-3">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <p class="text-jusify">Hausworth Nigeria Limited owners of 365 home improvements seeks human resource development firms in different areas of home improvement with a view towards working with them in the provision of quality training services to our users.</p>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <img src="" alt="Earnings_Image" class="d-block img-responsive img-fluid trainer_sidebar_image py-2 mb-2">
              <h6 class="text-center text-bold">MORE EARNINGS</h6>
              <p class="text-justify">Training company and trainer’s earns seventy percent (70%) of the cost price of the subscription on our platform. We take care of all the marketing and earn thirty percent (30%).</p>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <img src="" alt="Marketing_Image" class="d-block img-responsive img-fluid trainer_sidebar_image py-2 mb-2">
              <h6 class="text-center text-bold">GREATER MARKETING AND PUBLICITY</h6>
              <p class="text-justify">Hausworth Nigeria Limited would ensure maximum marketing and publicity of your trainings on different platforms both online and offline.
              Because we work with other training providers specializing in the different areas of interest, we would be able to attract different subscribers with possible interest in your contents.</p>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <img src="" alt="Payment_Image" class="d-block img-responsive img-fluid trainer_sidebar_image py-2 mb-2">
              <h6 class="text-center text-bold">PAYMENT</h6>
              <p class="text-justify">The amount earned can be easily seen along with your payment and earning history (transaction history).
              The payment would be remitted upon completion of the training. Payment would be made into your account directly.
              In order to become a training provider on our platform, please do provide us with the following details</p>
            </div>
          </div>
        </div>
      </div>
  	</div>

      
      
    </div>
  </section>

  <?php echo $__env->make('layouts.footer-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app-custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DEEONE\Desktop\Homeimprovement-Admin\resources\views/links/training/index.blade.php ENDPATH**/ ?>