<aside>
  <div id="sidebar" class="nav-collapse ">
    <!-- sidebar menu start-->
    <ul class="sidebar-menu" id="nav-accordion">
      <p class="centered"><a href="<?php echo e(url('#')); ?>"><img src="<?php echo e(Auth::user()->avatar); ?>" class="avatar"></a></p>
      <h5 class="centered"><?php echo e(Auth::user()->username); ?></h5>
      <li class="mt">
        <a class="active" href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="fa fa-dashboard"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li>
        <a href="<?php echo e(route('admin.profile')); ?>">
          <i class="fa fa-user"></i>
          <span>Profile</span>
        </a>
      </li>
      <li class="sidenav">
        <a href="<?php echo e(route('admin.contractor')); ?>">
          <i class="fa fa-user"></i>
          <span>Contractor</span>
        </a>
      </li>
      <li class="sidenav">
        <a href="<?php echo e(route('admin.category')); ?>">
          <i class="fa fa-list-alt"></i>
          <span>Categories</span>
        </a>
      </li>
      
      <li class="sub-menu">
        <a href="javascript:;">
          <i class="fa fa-desktop"></i> <span>UI Elements</span> <i class="fa fa-caret-down down-arrow"></i>
        </a>
        <ul class="sub admin">
          <li><a href="<?php echo e(url('#')); ?>">General</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Buttons</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Panels</a></li>
          <li><a href="<?php echo e(url('#')); ?>">Font Awesome</a></li>
        </ul>
      </li>
    </ul>
    <!-- sidebar menu end-->
  </div>
</aside>



<!--<script>
  $('a').click(function(){
    $('a.active').each(function(){
      $(this).removeClass('active');
    });
    $(this).addClass('active');
  });
</script>--><?php /**PATH E:\Laravel - 365home\Homeimprovement\resources\views/layouts/backend/admin-sidebar.blade.php ENDPATH**/ ?>