<?php echo e($slot); ?>

<?php /**PATH E:\Laravel - 365home\Homeimprovement\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>